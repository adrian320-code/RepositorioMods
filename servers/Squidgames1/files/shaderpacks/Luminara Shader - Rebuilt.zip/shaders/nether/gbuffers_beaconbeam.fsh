// Developed by EminGT
// Modified by Haider
#version 130

#define FRAGMENT_SHADER
#define NETHER
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers_beaconbeam.glsl"