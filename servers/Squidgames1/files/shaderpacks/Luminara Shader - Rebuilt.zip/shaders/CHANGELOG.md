# Changelog

## Performance Optimization - 2026-08-08

- Added a balanced 1080p profile for mid-range GPUs.
- Reduced default cloud ray-march steps and SSAO samples by half.
- Replaced expensive default water ray marching with a faster reflection path.
- Disabled full-screen block reflection ray marching by default.
- Optimized TAA neighbourhood and history sampling.
- Skipped inactive reflection, world-blur, TAA, and FXAA copy passes.
- Skipped post-process sharpening when TAA is inactive.
- Reduced default shadow distance and shadow filtering samples.
- Removed redundant shader includes and an unused texture fetch.
- Fixed Iris option warnings and a legacy block mapping warning.
- Fixed the Ultra-profile composite shader on NVIDIA GPUs by removing a reserved GLSL identifier, restoring reflection face-data lookup, and correcting declaration order.
- Corrected End Stone material coordinates inside world-space reflections.
- Reduced Ultra reflection voxel memory from 1.5 GiB to 384 MiB by using a 256-cell volume, keeping world-space reflections usable on 4 GB GPUs.
- Preserved water animation, bloom, daylight clarity, and sky effects.

## [Latest Update] - 2026-02-09

### 🌊 Water Enhancements
- Enabled dynamic water waves with realistic animation
- Added foam effects on water surface
- Increased wave intensity and movement speed

### 🌫️ Atmospheric Fog
- Implemented distance-based fog system at render borders
- Changed fog color to realistic gray tones
- Reduced fog intensity for better visibility

---
**Developed by EminGT**  
**Modified by Haider**
