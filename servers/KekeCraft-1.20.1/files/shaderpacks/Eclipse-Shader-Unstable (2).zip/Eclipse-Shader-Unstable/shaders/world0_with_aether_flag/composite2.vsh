#version 430 compatibility

#define OVERWORLD_SHADER
#define AETHER_FLAG

#include "/dimensions/composite2.vsh"