const mat3 agxInputTransform = mat3(
    0.842479062253094, 0.0423282422610123, 0.0423756549057051,
    0.0784335999999992, 0.878468636469772, 0.0784336,
    0.0792237451477643, 0.0791661274605434, 0.879142973793104
);

const mat3 agxOutputTransform = mat3(
    1.19687900512017, -0.0528968517574562, -0.0529716355144438,
    -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
    -0.0990297440797205, -0.0989611768448433, 1.15107367264116
);

const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
    vec3(1.660491, -0.124550, -0.018151),
    vec3(-0.587641, 1.132900, -0.100579),
    vec3(-0.072850, -0.008349, 1.118730)
);

const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
    vec3(0.627404, 0.069097, 0.016391),
    vec3(0.329283, 0.919540, 0.088013),
    vec3(0.043313, 0.011362, 0.895595)
);

const mat3 agxGamutAdjustment = mat3(
    0.969171893657971, 0.0286798190761981, 0.00214828726583143,
    0.0289319860577871, 0.906419509951623, 0.0646485039905892,
    0.00127358491330833, 0.0117497947477567, 0.986976620338936
);

vec3 AgXContrastResponse(vec3 value) {
    return (((((((-17.86 * value + 78.01) * value - 126.7) * value + 92.06) * value - 28.72) * value + 4.361) * value - 0.1718) * value + 0.002857);
}

float AgXShoulderCurve(float value) {
    const float pivot = 0.6057142857142858;
    const float curveScale = 0.5211124628937838;
    float distanceFromPivot = value - pivot;
    float normalizedDistance = 2.4 * distanceFromPivot / curveScale;
    float shapedDistance = normalizedDistance / pow(1.0 + pow(max(normalizedDistance, 0.0), 3.25), 1.0 / 3.25);
    return 0.5 + curveScale * shapedDistance;
}

float AgXToeCurve(float value) {
    const float pivot = 0.6057142857142858;
    const float curveScale = 0.5069714122510206;
    float normalizedDistance = 2.4 * (value - pivot) / -curveScale;
    float shapedDistance = normalizedDistance / pow(1.0 + pow(max(normalizedDistance, 0.0), 3.0), 1.0 / 3.0);
    return 0.5 - curveScale * shapedDistance;
}

float AgXDisplayCurve(float value) {
    return value < 0.6057142857142858 ? AgXToeCurve(value) : AgXShoulderCurve(value);
}

vec3 AgX_Minimal(vec3 value) {
    vec3 exposed = agxInputTransform * max(value, vec3(1e-7)) * 7.0;
    vec3 encoded = clamp(log2(exposed), -8.0, 6.0);
    encoded = (encoded + 8.0) / 14.0;
    encoded = AgXContrastResponse(encoded);
#ifdef COLOR_GRADING
    encoded = Contrast(encoded * BRIGHTNESS);
    encoded = pow(max(encoded, vec3(0.0)), vec3(rcp(GAMMA)));
    encoded = ColorSaturation(encoded, SATURATION);
#if WHITE_BALANCE != 6500
    encoded *= WhiteBalanceMatrix();
#endif
#endif
    return agxOutputTransform * encoded;
}

vec3 AgXConfigurable(vec3 value) {
    vec3 adjusted = value * agxGamutAdjustment;
    vec3 logSignal = clamp(log2(max(adjusted / 0.18, vec3(1e-7))), vec3(-8.48), vec3(5.52));
    vec3 normalizedSignal = (logSignal + 8.48) / 14.0;
    return clamp(vec3(
        AgXDisplayCurve(normalizedSignal.r),
        AgXDisplayCurve(normalizedSignal.g),
        AgXDisplayCurve(normalizedSignal.b)
    ), 0.0, 1.0);
}

vec3 AgX_Full(vec3 value) {
    vec3 wideGamut = LINEAR_SRGB_TO_LINEAR_REC2020 * max(value, vec3(0.0));
    wideGamut = AgXConfigurable(wideGamut);
    wideGamut = SRGBtoLinear(wideGamut);
    value = LINEAR_REC2020_TO_LINEAR_SRGB * wideGamut;
#ifdef COLOR_GRADING
    value = Contrast(value * BRIGHTNESS);
    value = pow(max(value, vec3(0.0)), vec3(rcp(GAMMA)));
    value = ColorSaturation(value, SATURATION);
#if WHITE_BALANCE != 6500
    value *= WhiteBalanceMatrix();
#endif
#endif
    return LinearToSRGB(value);
}
