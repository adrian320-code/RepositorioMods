float AuroraHash(vec2 p) {
    p = fract(p * vec2(0.1031, 0.1030));
    p += dot(p, p.yx + 33.33);
    return fract((p.x + p.y) * p.x);
}

float AuroraNoise(vec2 p) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = AuroraHash(cell);
    float b = AuroraHash(cell + vec2(1.0, 0.0));
    float c = AuroraHash(cell + vec2(0.0, 1.0));
    float d = AuroraHash(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float AuroraDensity(vec3 position, float altitude, float timeValue) {
    vec2 domain = position.xz * 0.000045;
    domain += vec2(timeValue * 0.013, -timeValue * 0.008);
    float broad = AuroraNoise(domain * 0.48);
    vec2 warped = domain + vec2(broad - 0.5, AuroraNoise(domain * 1.3) - 0.5) * 2.4;
    float medium = AuroraNoise(warped * 1.6);
    float fine = AuroraNoise(warped * 5.2 + vec2(-timeValue * 0.04, timeValue * 0.027));
    float ribbons = 0.5 + 0.5 * sin(warped.x * 2.8 + (medium - 0.5) * 5.0 + timeValue * 0.12);
    ribbons = pow(max(ribbons, 0.0), 7.0);
    float curtains = smoothstep(0.38, 0.82, 0.62 * medium + 0.38 * fine);
    float heightProfile = exp(-pow((altitude - 112000.0) / 23000.0, 2.0));
    return heightProfile * curtains * ribbons * (0.35 + 0.65 * fine);
}

vec3 NightAurora(in vec3 worldDir) {
    if (worldDir.y < 0.0 && eyeAltitude < 20000.0) return vec3(0.0);
    vec3 origin = vec3(0.0, planetRadius + eyeAltitude, 0.0);
    vec2 innerHit = RaySphereIntersection(origin, worldDir, planetRadius + 85000.0);
    vec2 outerHit = RaySphereIntersection(origin, worldDir, planetRadius + 150000.0);
    float startDistance = max(outerHit.x, 0.0);
    float endDistance = outerHit.y;
    if (eyeAltitude < 85000.0) {
        startDistance = max(innerHit.y, 0.0);
    } else if (innerHit.x > startDistance) {
        endDistance = min(endDistance, innerHit.x);
    }
    if (endDistance <= startDistance || endDistance > 650000.0) return vec3(0.0);
    float stepLength = (endDistance - startDistance) / 28.0;
    float timeValue = worldTimeCounter;
    vec3 emission = vec3(0.0);
    float transmittance = 1.0;
    for (int i = 0; i < 28; ++i) {
        float distanceAlongRay = startDistance + (float(i) + 0.5) * stepLength;
        vec3 samplePosition = origin + worldDir * distanceAlongRay;
        float altitude = length(samplePosition) - planetRadius;
        float density = AuroraDensity(samplePosition, altitude, timeValue);
        float sampleAlpha = 1.0 - exp(-density * stepLength * 0.000035);
        float altitudeBlend = saturate((altitude - 85000.0) / 65000.0);
        float detail = AuroraNoise(samplePosition.xz * 0.00012 + vec2(timeValue * 0.02));
        vec3 lowerColor = mix(vec3(0.025, 0.85, 0.42), vec3(0.06, 0.55, 0.95), detail);
        vec3 upperColor = mix(vec3(0.18, 0.22, 0.9), vec3(0.72, 0.12, 0.8), detail);
        vec3 sampleColor = mix(lowerColor, upperColor, altitudeBlend);
        emission += transmittance * sampleColor * sampleAlpha;
        transmittance *= 1.0 - sampleAlpha;
    }
    float horizonFade = smoothstep(-0.015, 0.22, worldDir.y);
    float distanceFade = exp(-startDistance * 0.0000015);
    return emission * auroraAmount * 3.2 * horizonFade * distanceFade;
}
