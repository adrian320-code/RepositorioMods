#version 450 compatibility

#include "/program/Gbuffers/EntitiesTranslucent.frag"
