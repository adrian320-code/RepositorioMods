#version 450 compatibility

#define LINES

#include "/program/Gbuffers/Line.frag"
