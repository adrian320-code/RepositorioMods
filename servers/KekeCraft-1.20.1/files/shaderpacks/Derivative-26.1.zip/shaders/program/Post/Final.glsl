
out vec3 finalData;

uniform vec3 sunPosition;
uniform float rainStrength;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

#include "/lib/Head/Noise.inc"

#define INFO 1		// [0 1]
#define Version 0	// [0 1 2 3]

//#define DEBUG_DRAWBUFFERS

//----------------------------------------------------------------------------//

#define minOf(a, b, c, d, e, f, g, h, i) min(a, min(b, min(c, min(d, min(e, min(f, min(g, min(h, i))))))))
#define maxOf(a, b, c, d, e, f, g, h, i) max(a, max(b, max(c, max(d, max(e, max(f, max(g, max(h, i))))))))

#define SampleColor(texel) texelFetch(colortex3, texel, 0).rgb

vec3 CASFilter(in ivec2 texel) {
    #ifndef CAS_ENABLED
        return SampleColor(texel);
    #endif
    vec3 nw = SampleColor(texel + ivec2(-1, -1));
    vec3 north = SampleColor(texel + ivec2(0, -1));
    vec3 ne = SampleColor(texel + ivec2(1, -1));
    vec3 west = SampleColor(texel + ivec2(-1, 0));
    vec3 center = SampleColor(texel);
    vec3 east = SampleColor(texel + ivec2(1, 0));
    vec3 sw = SampleColor(texel + ivec2(-1, 1));
    vec3 south = SampleColor(texel + ivec2(0, 1));
    vec3 se = SampleColor(texel + ivec2(1, 1));
    vec3 lowerBound = minOf(nw, north, ne, west, center, east, sw, south, se);
    vec3 upperBound = maxOf(nw, north, ne, west, center, east, sw, south, se);
    vec3 safeMaximum = max(upperBound, vec3(1e-6));
    vec3 headroom = max(min(vec3(1.0) - upperBound, lowerBound), vec3(0.0));
    vec3 adaptiveLimit = sqrt(headroom / safeMaximum);
    vec3 filterWeight = adaptiveLimit * mix(-0.125, -0.2, clamp(CAS_STRENGTH, 0.0, 1.0));
    vec3 crossSum = north + west + east + south;
    return (center + crossSum * filterWeight) / (1.0 + 4.0 * filterWeight);
}

//----------------------------------------------------------------------------//

//approximation from SMAA presentation from siggraph 2016
vec3 textureCatmullRomFast(in sampler2D tex, in vec2 position, in const float sharpness) {
	//vec2 screenSize = textureSize(sampler, 0);
	//vec2 screenPixelSize = 1.0 / screenSize;

	//vec2 position = screenSize * coord;
	vec2 centerPosition = floor(position - 0.5) + 0.5;
	vec2 f = position - centerPosition;
	vec2 f2 = f * f;
	vec2 f3 = f * f2;

	vec2 w0 = -sharpness        * f3 + 2.0 * sharpness         * f2 - sharpness * f;
	vec2 w1 = (2.0 - sharpness) * f3 - (3.0 - sharpness)       * f2 + 1.0;
	vec2 w2 = (sharpness - 2.0) * f3 + (3.0 - 2.0 * sharpness) * f2 + sharpness * f;
	vec2 w3 = sharpness         * f3 - sharpness               * f2;

	vec2 w12 = w1 + w2;

	vec2 tc0 = screenPixelSize * (centerPosition - 1.0);
	vec2 tc3 = screenPixelSize * (centerPosition + 2.0);
	vec2 tc12 = screenPixelSize * (centerPosition + w2 / w12);

	float l0 = w12.x * w0.y;
	float l1 = w0.x  * w12.y;
	float l2 = w12.x * w12.y;
	float l3 = w3.x  * w12.y;
	float l4 = w12.x * w3.y;

	vec3 color =  texture(tex, vec2(tc12.x, tc0.y )).rgb * l0
				+ texture(tex, vec2(tc0.x,  tc12.y)).rgb * l1
				+ texture(tex, vec2(tc12.x, tc12.y)).rgb * l2
				+ texture(tex, vec2(tc3.x,  tc12.y)).rgb * l3
				+ texture(tex, vec2(tc12.x, tc3.y )).rgb * l4;

	return color / (l0 + l1 + l2 + l3 + l4);
}

//----// MAIN //----------------------------------------------------------------------------------//
float fovmultLF = 1.0;

float ClampLensFlare(float x) {
	return clamp(x, 0.0, 1.0);
}

float BaseLens(vec2 tc, vec2 lp, float sz, float d, float hard) {
	vec2 lc = (tc + (lp * d - 0.5)) * vec2(aspectRatio, 1.0);
	float l = clamp(1.0 - length(lc) / (sz * fovmultLF), 0.0, 1.0 / hard) * hard;
	return l * l * l * l;
}

float OverlapLens(vec2 tc, vec2 lp, float sz, float da, float db) {
	return BaseLens(tc, lp, sz, da, 2.0) * BaseLens(tc, lp, sz, db, 2.0);
}

float PointLens(vec2 tc, vec2 lp, float sz, float d) {
	return BaseLens(tc, lp, sz, d, 1.5) + BaseLens(tc, lp, sz * 4.0, d, 1.0) * 0.5;
}

float RingLensTransform(float l) {
	return pow(1.0 - pow(1.0 - pow(l, 0.25), 10.0), 5.0);
}

float RingLens(vec2 tc, vec2 lp, float sz, float da, float db) {
	float l = ClampLensFlare(RingLensTransform(BaseLens(tc, lp, sz, db, 1.0))
		- RingLensTransform(BaseLens(tc, lp, sz, da, 1.0)));
	return l * sqrt(l);
}

float AnamorphicLens(vec2 tc, vec2 lp, float sz, float d) {
	vec2 lc = abs(tc + (lp * d - 0.5)) * vec2(aspectRatio * 0.07, 2.0);
	float l = ClampLensFlare(1.0 - length(pow(lc / (sz * fovmultLF), vec2(0.85))) * 4.0);
	return l * l * l;
}

vec3 RainbowLens(vec2 tc, vec2 lp, float sz, float d, float rad) {
	vec2 lc = (tc + (lp * d - 0.5)) * vec2(aspectRatio, 1.0);
	float l = ClampLensFlare(1.0 - length(lc) / (sz * fovmultLF));
	return (smoothstep(0.0, rad, l) - smoothstep(rad, rad * 2.0, l)) * vec3(1.0, 0.0, 0.0)
		+ (smoothstep(rad * 0.5, rad * 1.5, l) - smoothstep(rad * 1.5, rad * 2.5, l)) * vec3(0.0, 1.0, 0.0)
		+ (smoothstep(rad, rad * 2.0, l) - smoothstep(rad * 2.0, rad * 3.0, l)) * vec3(0.0, 0.0, 1.0);
}

vec3 GetLensFlare(vec2 tc, vec2 lightPos, float visibility, float strength) {
	vec3 lensFlare = vec3(0.0);
	float falloffBase = length(lightPos * vec2(aspectRatio, 1.0));
	float falloffIn = pow(ClampLensFlare(falloffBase * 10.0), 2.0);
	float falloffOut = ClampLensFlare(falloffBase * 3.0 - 1.5);
	if (falloffOut < 0.999) {
		lensFlare = (
			BaseLens(tc, lightPos, 0.3, -0.45, 1.0) * vec3(2.2, 1.2, 0.1) * 0.07 +
			BaseLens(tc, lightPos, 0.3,  0.10, 1.0) * vec3(2.2, 0.4, 0.1) * 0.03 +
			BaseLens(tc, lightPos, 0.3,  0.30, 1.0) * vec3(2.2, 0.2, 0.1) * 0.04 +
			BaseLens(tc, lightPos, 0.3,  0.50, 1.0) * vec3(2.2, 0.4, 2.5) * 0.05 +
			BaseLens(tc, lightPos, 0.3,  0.70, 1.0) * vec3(1.8, 0.4, 2.5) * 0.06 +
			BaseLens(tc, lightPos, 0.3,  0.95, 1.0) * vec3(0.1, 0.2, 2.5) * 0.10 +
			BaseLens(tc, lightPos, 0.3,  1.15, 1.0) * vec3(0.08, 0.1, 2.8) * 0.12 +
			BaseLens(tc, lightPos, 0.3,  1.35, 1.0) * vec3(0.04, 0.1, 3.4) * 0.14 +
			OverlapLens(tc, lightPos, 0.18, -0.30, -0.41) * vec3(2.5, 1.2, 0.1) * 0.010 +
			OverlapLens(tc, lightPos, 0.16, -0.18, -0.29) * vec3(2.5, 0.5, 0.1) * 0.020 +
			OverlapLens(tc, lightPos, 0.15,  0.06,  0.19) * vec3(2.5, 0.2, 0.1) * 0.015 +
			OverlapLens(tc, lightPos, 0.14,  0.15,  0.28) * vec3(1.8, 0.1, 1.2) * 0.015 +
			OverlapLens(tc, lightPos, 0.16,  0.24,  0.37) * vec3(1.0, 0.1, 2.5) * 0.015 +
			PointLens(tc, lightPos, 0.03, -0.55) * vec3(2.5, 1.6, 0.0) * 0.20 +
			PointLens(tc, lightPos, 0.02, -0.40) * vec3(2.5, 1.0, 0.0) * 0.15 +
			PointLens(tc, lightPos, 0.04,  0.43) * vec3(2.5, 0.6, 0.6) * 0.20 +
			PointLens(tc, lightPos, 0.02,  0.60) * vec3(0.2, 0.6, 2.5) * 0.15 +
			PointLens(tc, lightPos, 0.03,  0.67) * vec3(0.2, 1.6, 2.5) * 0.25 +
			PointLens(tc, lightPos, 0.03,  0.73) * vec3(0.2, 1.9, 2.5) * 0.35 +
			RingLens(tc, lightPos, 0.25, 0.43, 0.45) * vec3(0.10, 0.35, 2.50) * 1.5 +
			RingLens(tc, lightPos, 0.18, 0.98, 0.99) * vec3(0.15, 1.00, 2.55) * 2.5 +
			RingLens(tc, lightPos, 0.10, 1.32, 1.33) * vec3(0.30, 1.55, 2.85) * 1.5
		) * (falloffIn - falloffOut) + (
			AnamorphicLens(tc, lightPos, 1.0, -1.0) * vec3(0.3, 0.7, 1.0) * 0.35 +
			RainbowLens(tc, lightPos, 0.425, -1.0, 0.2) * 0.035 +
			RainbowLens(tc, lightPos, 2.0, 4.0, 0.1) * 0.05
		) * (1.0 - falloffOut);
		lensFlare *= visibility * strength * strength;
	}
	return lensFlare;
}

vec3 LensFlare(vec2 tc) {
	vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
	if (sunClip.w <= 1e-4) return vec3(0.0);
	fovmultLF = gbufferProjection[1][1] / 1.37373871;
	vec2 lightPos = sunClip.xy / sunClip.w * 0.5;
	vec2 sunUV = lightPos + 0.5;
	float sunDepth = texture(depthtex0, clamp(sunUV, screenPixelSize, 1.0 - screenPixelSize)).r;
	float visibility = smoothstep(0.992, 0.9998, sunDepth) * smoothstep(-0.10, 0.08, worldSunVector.y);
	return GetLensFlare(tc, lightPos, visibility, LENS_FLARE_STRENGTH);
}

vec3 ApplyChromaticAberration(vec2 uv, vec3 color) {
	vec2 coord = uv - 0.5;
	float dist = length(coord);
	float fovMask = mix(dist * 2.3, 1.0, 0.5);
	float amount = CHROMATIC_ABERRATION_STRENGTH * fovMask;
	vec2 offset = coord * amount;
	color.r = texture(colortex3, uv + offset).r;
	color.g = texture(colortex3, uv).g;
	color.b = texture(colortex3, uv - offset).b;
	return color;
}

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);

	#ifdef DEBUG_DRAWBUFFERS
		finalData = texelFetch(colortex4, texel, 0).rgb;
		return;
	#endif

	if (abs(MC_RENDER_QUALITY - 1.0) < 1e-2) {
    	finalData = CASFilter(texel);
	}else{
		finalData = textureCatmullRomFast(colortex3, texel * MC_RENDER_QUALITY, 0.6);
	}
	#ifdef CHROMATIC_ABERRATION_ENABLED
		finalData = ApplyChromaticAberration(gl_FragCoord.xy * screenPixelSize, finalData);
	#endif

	#if defined IS_OVERWORLD
		#ifdef LENS_FLARE_ENABLED
			if (rainStrength < 0.3) finalData = mix(finalData, vec3(1.0), LensFlare(gl_FragCoord.xy * screenPixelSize));
		#endif
	#endif
	ivec2 outlineTexel = clamp(ivec2(gl_FragCoord.xy * MC_RENDER_QUALITY), ivec2(0), ivec2(screenSize) - 1);
	if (int(texelFetch(colortex7, outlineTexel, 0).z * 255.0 + 0.5) == 253) finalData = vec3(1.0);
	finalData += (bayer16(gl_FragCoord.xy) - 0.5) * rcp(255.0);
}
