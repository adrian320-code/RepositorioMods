#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 albedoData;
layout(location = 1) out vec3 colortex7Out;
layout(location = 2) out vec2 colortex3Out;

/* DRAWBUFFERS:673 */

uniform sampler2D tex;
uniform float alphaTestRef;

in vec3 flatNormal;

in vec4 tint;
in vec2 texcoord;
in vec2 lightmap;
flat in int materialIDs;

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

void main() {
    vec4 texel = texture(tex, texcoord);
    float alpha = texel.a;

    if (alpha < alphaTestRef) {
        discard;
        return;
    }

    vec3 albedo = texel.rgb * tint.rgb;

    #ifdef WHITE_WORLD
        albedo.rgb = vec3(1.0);
    #endif

    albedoData = albedo;

    colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
    colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);
    colortex3Out = EncodeNormal(flatNormal);
}
