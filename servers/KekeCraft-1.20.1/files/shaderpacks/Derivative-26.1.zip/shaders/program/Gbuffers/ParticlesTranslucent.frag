layout(location = 0) out vec4 sceneColor;

/* DRAWBUFFERS:4 */

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"

uniform sampler2D tex;
uniform float alphaTestRef;

in vec4 tint;
in vec2 texcoord;

void main() {
    vec4 texel = texture(tex, texcoord);
    float alpha = texel.a * tint.a;
    if (alpha < alphaTestRef) discard;

    sceneColor = vec4(texel.rgb * tint.rgb, alpha);
}
