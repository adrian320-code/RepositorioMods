uniform int entityId;
uniform vec2 taaOffset;

out vec4 tint;
out vec2 texcoord;
out vec4 viewPos;
out vec2 lightmap;
out vec3 flatNormal;
flat out int materialIDs;

#include "/Settings.glsl"

void main() {
    tint = gl_Color;
    texcoord = gl_MultiTexCoord0.xy;
    lightmap = clamp(gl_MultiTexCoord1.xy * (1.0 / 240.0), 0.0, 1.0);
    flatNormal = normalize(gl_NormalMatrix * gl_Normal);
    viewPos = gl_ModelViewMatrix * gl_Vertex;
    gl_Position = gl_ProjectionMatrix * viewPos;

    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif

    materialIDs = max(entityId - 10000, 0);
}
