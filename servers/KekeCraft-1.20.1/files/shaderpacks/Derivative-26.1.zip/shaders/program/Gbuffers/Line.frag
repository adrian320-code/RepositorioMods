layout(location = 0) out vec4 sceneColor;
layout(location = 1) out vec3 albedoData;
layout(location = 2) out vec4 colortex7Out;

/* DRAWBUFFERS:467 */

flat in vec4 tint;
flat in int outlinePass;
in vec2 lightmap;

void main() {
    if (tint.a < 0.01) discard;

    sceneColor = vec4(tint.rgb, tint.a);
    albedoData = tint.rgb;
    colortex7Out = vec4(lightmap, 253.1 / 255.0, 1.0);
}
