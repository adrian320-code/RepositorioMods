#include "/lib/Head/Common.inc"

layout(location = 0) out vec3 albedoData;
layout(location = 1) out vec4 colortex7Out;

/* DRAWBUFFERS:67 */

//uniform mat4 gbufferModelView;

flat in vec4 tint;
flat in int outlinePass;
in vec2 lightmap;

float bayer2 (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
#define bayer4(a) (bayer2(0.5 * (a)) * 0.25 + bayer2(a))

void main() {
    if (tint.a < 0.01) {
        discard;
        return;
    }

    albedoData = tint.rgb;

    colortex7Out.xy = lightmap + (bayer4(gl_FragCoord.xy) - 0.5) * rcp(255.0);
    colortex7Out.z = (outlinePass == 1 ? 253.1 : 1.1) * rcp(255.0);
    //colortex3Out = EncodeNormal(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
}
