
#include "/Settings.glsl"

uniform vec2 taaOffset;
uniform int renderStage;
uniform float viewWidth;
uniform float viewHeight;

#define OUTLINE_WIDTH 2.5

flat out vec4 tint;
flat out int outlinePass;
out vec2 lightmap;

void main() {
	#ifdef LINES
		const float viewShrink = 1.0 - 1.0 / 256.0;
		vec4 startClip = gl_ProjectionMatrix * vec4((gl_ModelViewMatrix * gl_Vertex).xyz * viewShrink, 1.0);
		vec4 endClip = gl_ProjectionMatrix * vec4((gl_ModelViewMatrix * vec4(gl_Vertex.xyz + gl_Normal, 1.0)).xyz * viewShrink, 1.0);
		vec3 startNdc = startClip.xyz / startClip.w;
		vec3 endNdc = endClip.xyz / endClip.w;
		vec2 screenSize = vec2(viewWidth, viewHeight);
		vec2 lineDirection = normalize((endNdc.xy - startNdc.xy) * screenSize);
		vec2 lineOffset = vec2(-lineDirection.y, lineDirection.x) * OUTLINE_WIDTH / screenSize;
		if (lineOffset.x < 0.0) lineOffset = -lineOffset;
		float lineSide = (gl_VertexID & 1) == 0 ? 1.0 : -1.0;
		gl_Position = vec4((startNdc + vec3(lineOffset * lineSide, 0.0)) * startClip.w, startClip.w);
	#else
		gl_Position = ftransform();
	#endif

	#ifdef TAA_ENABLED
		gl_Position.xy += taaOffset * gl_Position.w;
	#endif

	tint = gl_Color;
	outlinePass = renderStage == MC_RENDER_STAGE_OUTLINE ? 1 : 0;
	#ifdef LINES
		outlinePass = 1;
	#endif
	if (outlinePass == 1) {
		tint = vec4(1.0);
		lightmap = vec2(0.0);
	}

	if (outlinePass == 0) lightmap = clamp((gl_MultiTexCoord1.xy - 8.0) / 232.0, 0.0, 1.0);
}
