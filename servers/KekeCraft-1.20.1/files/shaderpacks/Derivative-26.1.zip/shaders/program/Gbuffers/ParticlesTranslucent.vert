uniform vec2 taaOffset;
uniform sampler2D lightmap;

out vec4 tint;
out vec2 texcoord;

void main() {
    vec2 lightmapCoord = clamp(gl_MultiTexCoord1.xy * (1.0 / 256.0) + (0.5 / 16.0), vec2(0.5 / 16.0), vec2(15.5 / 16.0));
    tint = vec4(gl_Color.rgb * texture2D(lightmap, lightmapCoord).rgb, gl_Color.a);
    texcoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;
    gl_Position = ftransform();

    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif
}
