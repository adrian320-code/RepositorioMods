layout(location = 0) out vec4 sceneColor;
layout(location = 1) out vec4 colortex7Out;

/* DRAWBUFFERS:47 */

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Head/Functions.inc"

uniform sampler2D tex;
uniform vec4 entityColor;

in vec4 tint;
in vec2 texcoord;
in vec2 lightmap;
flat in int materialIDs;

void main() {
    vec4 texel = texture(tex, texcoord);
    if (texel.a < 0.1) discard;

    vec4 albedo = texel * tint;

    bool isNameTag = materialIDs == 35;


    if (isNameTag) {
        albedo.a = texel.a;
    }

    #ifdef ENTITY_STATUS_COLOR
        albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
    #endif

    if (materialIDs == 12) albedo = vec4(0.6, 0.5, 1.0, 1.0);

    #ifdef WHITE_WORLD
        albedo.rgb = vec3(1.0);
    #endif

    float light = isNameTag ? 1.0 : max(max(lightmap.x, lightmap.y), 0.02);

    sceneColor = vec4(SRGBtoLinear(albedo.rgb) * light, albedo.a);


    colortex7Out = vec4(
        lightmap,
        254.1 / 255.0,
        isNameTag ? 0.0 : 1.0
    );
}
