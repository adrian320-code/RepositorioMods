#version 450 compatibility

#define IS_END

#include "/program/Gbuffers/ParticlesTranslucent.frag"
