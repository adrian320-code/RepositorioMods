#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_SKYBASIC

#include "/program/world/sky_basic.glsl"
