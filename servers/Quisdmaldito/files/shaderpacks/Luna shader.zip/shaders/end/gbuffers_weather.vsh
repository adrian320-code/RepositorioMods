#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_WEATHER

#include "/program/world/weather.glsl"
