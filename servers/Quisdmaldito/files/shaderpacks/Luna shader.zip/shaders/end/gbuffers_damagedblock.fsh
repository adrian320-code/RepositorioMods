#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_DAMAGED_BLOCK

#include "/program/world/damaged_block.glsl"
