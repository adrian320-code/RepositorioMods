#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_WATER

#include "/program/world/water.glsl"
