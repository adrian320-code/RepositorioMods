#version 130

#define VERTEX_SHADER
#define END
#define LU_COMPOSITE3

#include "/program/pass/pass3.glsl"
