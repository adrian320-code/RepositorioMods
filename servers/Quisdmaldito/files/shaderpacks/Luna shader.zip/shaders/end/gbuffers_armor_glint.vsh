#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_ARMOR_GLINT

#include "/program/world/armor_glint.glsl"
