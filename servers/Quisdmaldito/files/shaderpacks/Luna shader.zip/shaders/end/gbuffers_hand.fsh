#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_HAND

#include "/program/world/hand.glsl"
