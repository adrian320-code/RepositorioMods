#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_BEACONBEAM

#include "/program/world/beacon_beam.glsl"
