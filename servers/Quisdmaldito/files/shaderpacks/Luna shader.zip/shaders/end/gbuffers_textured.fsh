#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_TEXTURED

#include "/program/world/textured.glsl"
