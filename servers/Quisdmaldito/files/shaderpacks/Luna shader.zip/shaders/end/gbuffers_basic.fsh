#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_BASIC

#include "/program/world/basic.glsl"
