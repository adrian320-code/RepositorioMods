#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_SPIDEREYES

#include "/program/world/spider_eyes.glsl"
