#version 130

#define VERTEX_SHADER
#define END
#define LU_SHADOW

#include "/program/shadow.glsl"
