#version 130

#define FRAGMENT_SHADER
#define END
#define LU_SHADOW

#include "/program/shadow.glsl"
