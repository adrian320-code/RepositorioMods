#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_BASIC

#include "/program/world/basic.glsl"
