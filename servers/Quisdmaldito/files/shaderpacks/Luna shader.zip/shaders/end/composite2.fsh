#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE2

#include "/program/pass/pass2.glsl"
