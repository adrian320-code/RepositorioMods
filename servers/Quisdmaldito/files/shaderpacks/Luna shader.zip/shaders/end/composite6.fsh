#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE6

#include "/program/pass/pass6.glsl"
