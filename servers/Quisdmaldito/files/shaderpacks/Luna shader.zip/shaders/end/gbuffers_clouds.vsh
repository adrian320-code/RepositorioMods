#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
