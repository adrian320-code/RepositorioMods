#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_SKYTEXTURED

#include "/program/world/sky_textured.glsl"
