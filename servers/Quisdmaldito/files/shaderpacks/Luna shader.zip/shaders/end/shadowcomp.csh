#version 430 compatibility

#define COMPUTE_SHADER
#define END
#define LU_SHADOWCOMP

#include "/program/post/shadow_pass.glsl"
