#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
