#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_ENTITIES

#include "/program/world/entity.glsl"
