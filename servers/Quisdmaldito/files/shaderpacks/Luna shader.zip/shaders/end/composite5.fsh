#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE5

#include "/program/pass/pass5.glsl"
