#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_ENTITIES
#define LU_GBUFFERS_ENTITIES_GLOWING

#include "/program/world/entity.glsl"
