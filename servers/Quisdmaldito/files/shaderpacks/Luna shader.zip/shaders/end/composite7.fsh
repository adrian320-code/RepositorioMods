#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE7

#include "/program/pass/pass7.glsl"
