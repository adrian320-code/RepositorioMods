#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_BLOCK

#include "/program/world/block_entity.glsl"
