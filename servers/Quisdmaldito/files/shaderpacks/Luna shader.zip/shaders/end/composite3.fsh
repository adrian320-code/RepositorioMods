#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE3

#include "/program/pass/pass3.glsl"
