#version 130

#define VERTEX_SHADER
#define END
#define LU_COMPOSITE

#include "/program/pass/pass1.glsl"
