#version 130

#define VERTEX_SHADER
#define END
#define LU_GBUFFERS_TERRAIN

#include "/program/world/terrain.glsl"
