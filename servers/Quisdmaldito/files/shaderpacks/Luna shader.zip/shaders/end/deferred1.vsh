#version 130

#define VERTEX_SHADER
#define END
#define LU_DEFERRED1

#include "/program/deferred.glsl"
