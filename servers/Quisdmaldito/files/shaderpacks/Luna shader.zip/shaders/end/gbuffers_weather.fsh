#version 130

#define FRAGMENT_SHADER
#define END
#define LU_GBUFFERS_WEATHER

#include "/program/world/weather.glsl"
