#version 130

#define FRAGMENT_SHADER
#define END
#define LU_COMPOSITE4

#include "/program/pass/pass4.glsl"
