#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_ENTITIES
#define LU_GBUFFERS_ENTITIES_GLOWING

#include "/program/world/entity.glsl"
