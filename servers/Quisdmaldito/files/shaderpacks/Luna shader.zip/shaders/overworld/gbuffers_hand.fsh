#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_HAND

#include "/program/world/hand.glsl"
