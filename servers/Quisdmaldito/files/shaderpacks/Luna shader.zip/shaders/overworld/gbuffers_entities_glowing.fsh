#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_ENTITIES_GLOWING

#include "/program/world/entity.glsl"
