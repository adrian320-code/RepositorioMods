#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_SHADOW

#include "/program/shadow.glsl"
