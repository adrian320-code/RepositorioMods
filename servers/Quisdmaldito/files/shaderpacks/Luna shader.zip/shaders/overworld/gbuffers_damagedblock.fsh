#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_DAMAGED_BLOCK

#include "/program/world/damaged_block.glsl"
