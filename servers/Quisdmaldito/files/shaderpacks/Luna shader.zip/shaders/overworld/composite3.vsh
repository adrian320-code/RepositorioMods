#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_COMPOSITE3

#include "/program/pass/pass3.glsl"
