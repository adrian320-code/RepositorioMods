#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_TERRAIN

#include "/program/world/terrain.glsl"
