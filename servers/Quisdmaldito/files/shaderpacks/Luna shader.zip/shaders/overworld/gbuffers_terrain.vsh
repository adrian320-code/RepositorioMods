#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_TERRAIN

#include "/program/world/terrain.glsl"
