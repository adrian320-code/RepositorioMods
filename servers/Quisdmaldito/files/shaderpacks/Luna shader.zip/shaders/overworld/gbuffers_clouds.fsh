#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
