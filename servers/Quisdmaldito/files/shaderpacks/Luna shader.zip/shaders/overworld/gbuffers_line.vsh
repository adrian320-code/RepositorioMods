#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_BASIC
#define LU_GBUFFERS_LINE

#include "/program/world/basic.glsl"
