#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
