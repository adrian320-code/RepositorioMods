#version 430 compatibility

#define COMPUTE_SHADER
#define OVERWORLD
#define LU_SHADOWCOMP

#include "/program/post/shadow_pass.glsl"
