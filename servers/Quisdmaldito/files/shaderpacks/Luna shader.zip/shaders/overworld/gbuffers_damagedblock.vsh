#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_DAMAGED_BLOCK

#include "/program/world/damaged_block.glsl"
