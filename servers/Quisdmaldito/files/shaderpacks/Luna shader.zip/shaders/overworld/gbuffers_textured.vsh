#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_TEXTURED

#include "/program/world/textured.glsl"
