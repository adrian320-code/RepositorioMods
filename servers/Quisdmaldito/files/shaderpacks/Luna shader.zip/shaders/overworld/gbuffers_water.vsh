#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_WATER

#include "/program/world/water.glsl"
