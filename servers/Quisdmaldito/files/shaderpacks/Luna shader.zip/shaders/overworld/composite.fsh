#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_COMPOSITE

#include "/program/pass/pass1.glsl"
