#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_BASIC

#include "/program/world/basic.glsl"
