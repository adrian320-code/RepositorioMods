#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_SKYTEXTURED

#include "/program/world/sky_textured.glsl"
