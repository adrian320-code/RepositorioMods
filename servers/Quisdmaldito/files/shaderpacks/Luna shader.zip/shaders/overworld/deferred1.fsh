#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_DEFERRED1

#include "/program/deferred.glsl"
