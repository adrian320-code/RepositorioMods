#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_ENTITIES

#include "/program/world/entity.glsl"
