#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define LU_GBUFFERS_SPIDEREYES

#include "/program/world/spider_eyes.glsl"
