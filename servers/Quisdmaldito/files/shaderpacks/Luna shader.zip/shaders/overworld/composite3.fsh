#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_COMPOSITE3

#include "/program/pass/pass3.glsl"
