#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_LINE

#include "/program/world/basic.glsl"
