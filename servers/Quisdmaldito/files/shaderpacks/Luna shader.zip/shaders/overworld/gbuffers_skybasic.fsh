#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define LU_GBUFFERS_SKYBASIC

#include "/program/world/sky_basic.glsl"
