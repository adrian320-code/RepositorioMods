// Core Libraries
#include "/lib/config/master.glsl"

/**
 * FRAGMENT SHADER - Color Processing
 * tonemapping and color correction
 */
#ifdef FRAGMENT_SHADER

// Input Variables
noperspective in vec2 texCoord;     // Screen texture coordinates

#if defined LU_BLOOM_FOG || LU_LENSFLARE_MODE > 0 && defined OVERWORLD
    flat in vec3 upVec, sunVec;     // Direction vectors for bloom and lens flare
#endif

//========================================
// Pipeline Constants Section
/* ==========================================
 * TONEMAPPING VARIABLES
 * ========================================== */
// Pixel size calculations for sampling
float pw = 1.0 / viewWidth;
float ph = 1.0 / viewHeight;

// Screen dimensions vector
vec2 view = vec2(viewWidth, viewHeight);

#if defined LU_BLOOM_FOG || LU_LENSFLARE_MODE > 0 && defined OVERWORLD
    // Sun visibility calculations for atmospheric effects
    float SdotU = dot(sunVec, upVec);
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
#endif

/* ==========================================
 * COLOR CORRECTION FUNCTIONS - Lunara
 * ========================================== */
void lu_DoHighNoonTonemap(inout vec3 color) {
    color = LU_T_EXPOSURE * color;
    color = color / pow(pow(color, vec3(LU_TM_WHITE_CURVE)) + 1.0, vec3(1.0 / LU_TM_WHITE_CURVE));
    color = pow(color, mix(vec3(LU_T_LOWER_CURVE), vec3(LU_T_UPPER_CURVE), sqrt(color)));

    color = pow(color, vec3(1.0 / 2.2));
}

void lu_DoHighNoonColorSaturation(inout vec3 color) {
    float grayVibrance = (color.r + color.g + color.b) / 3.0;
    float graySaturation = grayVibrance;
    if (LU_T_SATURATION < 1.00) graySaturation = dot(color, vec3(0.299, 0.587, 0.114));

    float mn = min(color.r, min(color.g, color.b));
    float mx = max(color.r, max(color.g, color.b));
    float sat = (1.0 - (mx - mn)) * (1.0 - mx) * grayVibrance * 5.0;
    vec3 lightness = vec3((mn + mx) * 0.5);

    color = mix(color, mix(color, lightness, 1.0 - LU_T_VIBRANCE), sat);
    color = mix(color, lightness, (1.0 - lightness) * (2.0 - LU_T_VIBRANCE) / 2.0 * abs(LU_T_VIBRANCE - 1.0));
    color = color * LU_T_SATURATION - graySaturation * (LU_T_SATURATION - 1.0);
}

#ifdef LU_BLOOM
    vec2 rescale = max(vec2(viewWidth, viewHeight) / vec2(1920.0, 1080.0), vec2(1.0));
    vec3 GetBloomTile(float lod, vec2 coord, vec2 offset) {
        float scale = exp2(lod);
        vec2 bloomCoord = coord / scale + offset;
        bloomCoord = clamp(bloomCoord, offset, 1.0 / scale + offset);

        vec3 bloom = texture2D(colortex3, bloomCoord / rescale).rgb;
        bloom *= bloom;
        bloom *= bloom;
        return bloom * 128.0;
    }

    void DoBloom(inout vec3 color, vec2 coord, float dither, float lViewPos) {
        vec3 blur1 = GetBloomTile(2.0, coord, vec2(0.0      , 0.0   ));
        vec3 blur2 = GetBloomTile(3.0, coord, vec2(0.0      , 0.26  ));
        vec3 blur3 = GetBloomTile(4.0, coord, vec2(0.135    , 0.26  ));
        vec3 blur4 = GetBloomTile(5.0, coord, vec2(0.2075   , 0.26  ));
        vec3 blur5 = GetBloomTile(6.0, coord, vec2(0.135    , 0.3325));
        vec3 blur6 = GetBloomTile(7.0, coord, vec2(0.160625 , 0.3325));
        vec3 blur7 = GetBloomTile(8.0, coord, vec2(0.1784375, 0.3325));

        vec3 blur = (blur1 + blur2 + blur3 + blur4 + blur5 + blur6 + blur7) * 0.14;

        float bloomStrength = LU_BLOOM_STRENGTH + 0.2 * darknessFactor;

        #if defined LU_BLOOM_FOG && defined NETHER && defined LU_BORDER_FOG
            float farM = min(renderDistance, LU_NETHER_VIEW_LIMIT);
            float netherBloom = lViewPos / clamp(farM, 96.0, 256.0);
            netherBloom *= netherBloom;
            netherBloom *= netherBloom;
            netherBloom = 1.0 - exp(-8.0 * netherBloom);
            netherBloom *= 1.0 - maxBlindnessDarkness;
            bloomStrength = mix(bloomStrength * 0.7, bloomStrength * 1.8, netherBloom);
        #endif

        color = mix(color, blur, bloomStrength);
    }
#endif

/* ==========================================
 * LIBRARY INCLUDES
 * ========================================== */
#ifdef LU_BLOOM_FOG
    #include "/lib/sky/aero/bloom.glsl"
#endif

#ifdef LU_BLOOM
    #include "/lib/sky/globals.glsl"
#endif

#if LU_LENSFLARE_MODE > 0 && defined OVERWORLD
    #include "/lib/fx/unified.glsl"
#endif

/**
 * MAIN PROGRAM - Color Processing Stage
 */
void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;

    #if defined LU_BLOOM_FOG || LU_LENSFLARE_MODE > 0 && defined OVERWORLD
        float z0 = texture2D(depthtex0, texCoord).r;

        vec4 screenPos = vec4(texCoord, z0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
        viewPos /= viewPos.w;
        float lViewPos = length(viewPos.xyz);

        #if defined DISTANT_HORIZONS && defined NETHER
            float z0DH = texelFetch(dhDepthTex, texelCoord, 0).r;
            vec4 screenPosDH = vec4(texCoord, z0DH, 1.0);
            vec4 viewPosDH = dhProjectionInverse * (screenPosDH * 2.0 - 1.0);
            viewPosDH /= viewPosDH.w;
            lViewPos = min(lViewPos, length(viewPosDH.xyz));
        #endif
    #else
        float lViewPos = 0.0;
    #endif

    float dither = texture2D(noisetex, texCoord * view / 128.0).b;
    #ifdef LU_TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #ifdef LU_BLOOM_FOG
        color /= LU_GetBloomFog(lViewPos);
    #endif

    #ifdef LU_BLOOM
        DoBloom(color, texCoord, dither, lViewPos);
    #endif

    #ifdef LU_COLORGRADING
        color =
            pow(color.r, LU_GR_RC) * vec3(LU_GR_RR, LU_GR_RG, LU_GR_RB) +
            pow(color.g, LU_GR_GC) * vec3(LU_GR_GR, LU_GR_GG, LU_GR_GB) +
            pow(color.b, LU_GR_BC) * vec3(LU_GR_BR, LU_GR_BG, LU_GR_BB);
        color *= 0.01;
    #endif

    lu_DoHighNoonTonemap(color);

    #if defined LU_GREEN_SCREEN_LIME || LU_SELECT_OUTLINE == 4
        int materialMaskInt = int(texelFetch(colortex6, texelCoord, 0).g * 255.1);
    #endif

    #ifdef LU_GREEN_SCREEN_LIME
        if (materialMaskInt == 240) {
            color = vec3(0.0, 1.0, 0.0);  // Green Screen Lime Blocks
        }
    #endif

    #if LU_SELECT_OUTLINE == 4
        if (materialMaskInt == 252) {  // Versatile Selection Outline
            float colorMF = 1.0 - dot(color, vec3(0.25, 0.45, 0.1));
            colorMF = lu_smoothstep1(lu_smoothstep1(lu_smoothstep1(lu_smoothstep1(lu_smoothstep1(colorMF)))));
            color = mix(color, 3.0 * (color + 0.2) * vec3(colorMF * LU_SELECT_OUTLINE_I), 0.3);
        }
    #endif

    #if LU_LENSFLARE_MODE > 0 && defined OVERWORLD
        lu_DoLensFlare(color, viewPos.xyz, dither);
    #endif

    lu_DoHighNoonColorSaturation(color);

    float filmGrain = dither;
    color += vec3((filmGrain - 0.25) / 128.0);

    /* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(color, 1.0);
}

#endif

/*============================================
 * VERTEX SHADER - Screen Pass Setup
 *============================================*/
#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

#if defined LU_BLOOM_FOG || LU_LENSFLARE_MODE > 0 && defined OVERWORLD
    flat out vec3 upVec, sunVec;
#endif

/**
 * MAIN VERTEX PROGRAM - Lunara Implementation
 */
void main() {
    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    #if defined LU_BLOOM_FOG || LU_LENSFLARE_MODE > 0 && defined OVERWORLD
        upVec = normalize(gbufferModelView[1].xyz);
        sunVec = GetSunVector();
    #endif
}

#endif
