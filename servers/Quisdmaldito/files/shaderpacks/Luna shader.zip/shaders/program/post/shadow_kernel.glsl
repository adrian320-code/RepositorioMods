
#include "/lib/config/master.glsl"

#ifdef LU_SHADOWCOMP

#define LU_OPTIMIZATION_ACL_HALF_RATE_UPDATES
#define LU_OPTIMIZATION_ACL_BEHIND_PLAYER

layout (local_size_x = 8, local_size_y = 8, local_size_z = 8) in;

#if LU_COLORED_LIGHTING_INTERNAL == 128
	const ivec3 workGroups = ivec3(16, 8, 16);
#elif LU_COLORED_LIGHTING_INTERNAL == 192
	const ivec3 workGroups = ivec3(24, 12, 24);
#elif LU_COLORED_LIGHTING_INTERNAL == 256
	const ivec3 workGroups = ivec3(32, 16, 32);
#elif LU_COLORED_LIGHTING_INTERNAL == 384
	const ivec3 workGroups = ivec3(48, 24, 48);
#elif LU_COLORED_LIGHTING_INTERNAL == 512
	const ivec3 workGroups = ivec3(64, 32, 64);
#elif LU_COLORED_LIGHTING_INTERNAL == 768
	const ivec3 workGroups = ivec3(96, 32, 96);
#elif LU_COLORED_LIGHTING_INTERNAL == 1024
	const ivec3 workGroups = ivec3(128, 32, 128);
#endif

ivec3[6] face_offsets = ivec3[6](
	ivec3( 1,  0,  0),
	ivec3( 0,  1,  0),
	ivec3( 0,  0,  1),
	ivec3(-1,  0,  0),
	ivec3( 0, -1,  0),
	ivec3( 0,  0, -1)
);

writeonly uniform image3D floodfill_img;
writeonly uniform image3D floodfill_img_copy;

vec4 lu_GetLightSample(sampler3D lightSampler, ivec3 pos) {
	return texelFetch(lightSampler, pos, 0);
}

vec4 lu_GetLightAverage(sampler3D lightSampler, ivec3 pos, ivec3 voxelVolumeSize) {

	vec4 light_old = lu_GetLightSample(lightSampler, pos);

	vec4 light_px  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[0], ivec3(0), voxelVolumeSize - 1));
	vec4 light_py  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[1], ivec3(0), voxelVolumeSize - 1));
	vec4 light_pz  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[2], ivec3(0), voxelVolumeSize - 1));
	vec4 light_nx  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[3], ivec3(0), voxelVolumeSize - 1));
	vec4 light_ny  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[4], ivec3(0), voxelVolumeSize - 1));
	vec4 light_nz  = lu_GetLightSample(lightSampler, clamp(pos + face_offsets[5], ivec3(0), voxelVolumeSize - 1));

	vec4 light = light_old + light_px + light_py + light_pz + light_nx + light_ny + light_nz;
    return light / 7.2;
}

#include "/lib/fx/unified.glsl"

void main() {

	ivec3 pos = ivec3(gl_GlobalInvocationID);
	vec3 posM = vec3(pos) / vec3(voxelVolumeSize);
	vec3 posOffset = floor(previousCameraPosition) - floor(cameraPosition);
	ivec3 previousPos = ivec3(vec3(pos) - posOffset);

	ivec3 absPosFromCenter = abs(pos - voxelVolumeSize / 2);
	if (absPosFromCenter.x + absPosFromCenter.y + absPosFromCenter.z > 16) {
	#ifdef LU_OPTIMIZATION_ACL_BEHIND_PLAYER

		vec4 viewPos = gbufferProjectionInverse * vec4(0.0, 0.0, 1.0, 1.0);
		viewPos /= viewPos.w;
		vec3 nPlayerPos = normalize(mat3(gbufferModelViewInverse) * viewPos.xyz);

		if (dot(normalize(posM - 0.5), nPlayerPos) < 0.0) {
			#ifdef LU_COLORED_LIGHT_FOG

				if ((frameCounter & 1) == 0) {
					imageStore(floodfill_img_copy, pos, lu_GetLightSample(floodfill_sampler, previousPos));
				} else {
					imageStore(floodfill_img, pos, lu_GetLightSample(floodfill_sampler_copy, previousPos));
				}
			#endif
			return;
		}
	#endif
	}

	vec4 light = vec4(0.0);
	uint voxel = texelFetch(voxel_sampler, pos, 0).x;

	if ((frameCounter & 1) == 0) {

		if (voxel == 1u) {
			imageStore(floodfill_img_copy, pos, vec4(0.0));
			return;
		}

		#ifdef LU_OPTIMIZATION_ACL_HALF_RATE_UPDATES

			if (posM.x < 0.5) {
				imageStore(floodfill_img_copy, pos, lu_GetLightSample(floodfill_sampler, previousPos));
				return;
			}
		#endif

		light = lu_GetLightAverage(floodfill_sampler, previousPos, voxelVolumeSize);
	} else {

		if (voxel == 1u) {
			imageStore(floodfill_img, pos, vec4(0.0));
			return;
		}

		#ifdef LU_OPTIMIZATION_ACL_HALF_RATE_UPDATES

			if (posM.x > 0.5) {
				imageStore(floodfill_img, pos, lu_GetLightSample(floodfill_sampler_copy, previousPos));
				return;
			}
		#endif

		light = lu_GetLightAverage(floodfill_sampler_copy, previousPos, voxelVolumeSize);
	}

	if (voxel == 0u || voxel >= 200u) {

		if (voxel >= 200u) {
			vec3 tint = specialTintColor[min(voxel - 200u, specialTintColor.length() - 1u)];
			light.rgb *= tint;
		}
	} else {

		vec4 color = lu_GetSpecialBlocklightColor(int(voxel));
		light = max(light, vec4(lu_pow2(color.rgb), color.a));
	}

	if ((frameCounter & 1) == 0) {
		imageStore(floodfill_img_copy, pos, light);
	} else {
		imageStore(floodfill_img, pos, light);
	}
}

#endif
