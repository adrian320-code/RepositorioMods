
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

noperspective in vec2 texCoord;

#if LU_IMAGE_SHARPENING > 0
    vec2 viewD = 1.0 / vec2(viewWidth, viewHeight);

    vec2 sharpenOffsets[4] = vec2[4](
        vec2( viewD.x,  0.0),
        vec2( 0.0,  viewD.y),
        vec2(-viewD.x,  0.0),
        vec2( 0.0, -viewD.y)
    );

    void SharpenImage(inout vec3 color, vec2 texCoordM) {
        #ifdef LU_TAA
            float sharpenMult = LU_IMAGE_SHARPENING;
        #else
            float sharpenMult = LU_IMAGE_SHARPENING * 0.5;
        #endif

        float mult = 0.0125 * sharpenMult;

        color *= 1.0 + 0.05 * sharpenMult;

        for (int i = 0; i < 4; i++) {
            color -= texture2D(colortex3, texCoordM + sharpenOffsets[i]).rgb * mult;
        }
    }
#endif

void main() {
    vec2 texCoordM = texCoord;

    #ifdef LU_UNDERWATER_DISTORTION
        if (isEyeInWater == 1) {
            float underwaterWeatherF = lu_clamp01(rainFactor * max(inRainy, 0.35));
            vec2 waveA = vec2(
                sin(texCoord.y * 58.0 + texCoord.x * 13.0 + frameTimeCounter * 1.55),
                cos(texCoord.x * 47.0 - texCoord.y * 19.0 - frameTimeCounter * 1.20)
            );
            vec2 waveB = vec2(
                sin((texCoord.x + texCoord.y) * 31.0 - frameTimeCounter * 0.88),
                cos((texCoord.x - texCoord.y) * 36.0 + frameTimeCounter * 1.05)
            );
            texCoordM += LU_WATER_REFRACTION_INTENSITY * (0.00042 + 0.00030 * underwaterWeatherF) *
                         (waveA * 0.62 + waveB * 0.38);
        }
    #endif

    vec3 color = texture2D(colortex3, texCoordM).rgb;

    #if LU_CHROMA_ABERRATION > 0
        vec2 scale = vec2(1.0, viewHeight / viewWidth);
        vec2 aberration = (texCoordM - 0.5) * (2.0 / vec2(viewWidth, viewHeight)) *
                          scale * LU_CHROMA_ABERRATION;

        color.rb = vec2(texture2D(colortex3, texCoordM + aberration).r,
                        texture2D(colortex3, texCoordM - aberration).b);
    #endif

    #if LU_IMAGE_SHARPENING > 0
        SharpenImage(color, texCoordM);
    #endif

    if (isEyeInWater == 1) {
        float underwaterWeatherF2 = lu_clamp01(rainFactor * max(inRainy, 0.35));
        vec3 underwaterFinalDay = vec3(0.045, 0.230, 0.400);
        vec3 underwaterFinalNight = vec3(0.010, 0.030, 0.105);
        vec3 underwaterFinalRain = vec3(0.022, 0.065, 0.095);
        vec3 underwaterFinalTint = mix(underwaterFinalNight, underwaterFinalDay, noonFactor);
        underwaterFinalTint = mix(underwaterFinalTint, underwaterFinalRain, underwaterWeatherF2 * 0.78);

        vec2 waterUV = texCoordM * vec2(aspectRatio, 1.0);
        float ribbonA = sin(waterUV.x * 42.0 + waterUV.y * 16.0 + frameTimeCounter * 1.10);
        float ribbonB = sin(waterUV.x * -24.0 + waterUV.y * 39.0 - frameTimeCounter * 0.92);
        float lightRibbon = lu_pow2(lu_max0(ribbonA * 0.5 + ribbonB * 0.5 - 0.22));
        lightRibbon *= (1.0 - underwaterWeatherF2 * 0.70) * (0.020 + 0.045 * noonFactor);

        color = mix(color, underwaterFinalTint * (0.58 + 0.28 * vsBrightness), 0.050 + 0.055 * underwaterWeatherF2 + 0.030 * nightFactor);
        color += vec3(0.070, 0.180, 0.230) * lightRibbon;

        vec2 fromCenter = texCoord - 0.5;
        color *= 1.0 - dot(fromCenter, fromCenter) * (0.10 + 0.06 * underwaterWeatherF2);
    }

    #if defined OVERWORLD && LU_BIOME_COLOR_GRADING == 1

        if (inDesert > 0.001) {
            float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
            vec3 desertTint = vec3(1.12, 1.04, 0.85);
            vec3 desaturated = mix(color, vec3(luma), 0.15);
            vec3 desertColor = desaturated * desertTint;
            desertColor = mix(vec3(luma), desertColor, 1.08);
            color = mix(color, desertColor, inDesert);
        }
    #endif

    #if defined OVERWORLD && LU_BIOME_COLOR_GRADING == 1

        if (inSnowy > 0.001) {
            float lumaS = dot(color, vec3(0.2126, 0.7152, 0.0722));
            vec3 snowTint = vec3(0.88, 0.93, 1.10);
            vec3 desaturatedS = mix(color, vec3(lumaS), 0.22);
            vec3 snowColor = desaturatedS * snowTint;
            snowColor += vec3(0.012, 0.015, 0.025) * lumaS;
            color = mix(color, snowColor, inSnowy);
        }
    #endif

    #ifdef LU_VIGNETTE_R
        vec2 texCoordMin = texCoordM.xy - 0.5;
        float vignette = 1.0 - dot(texCoordMin, texCoordMin) * (1.0 - lu_GetLuminance(color));
        color *= vignette;
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

#endif

#ifdef VERTEX_SHADER

noperspective out vec2 texCoord;

void main() {
    gl_Position = ftransform();
    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}

#endif
