#include "/lib/config/master.glsl"

#ifdef LU_SHADOWCOMP

layout (local_size_x = 8, local_size_y = 8, local_size_z = 8) in;

writeonly uniform image3D floodfill_img;
writeonly uniform image3D floodfill_img_copy;

uniform sampler3D floodfill_sampler;
uniform sampler3D floodfill_sampler_copy;
uniform usampler3D voxel_sampler;

void main() {

    ivec3 pos = ivec3(gl_GlobalInvocationID);

    vec4 light = vec4(0.0);

    imageStore(floodfill_img, pos, light);
}

#endif
