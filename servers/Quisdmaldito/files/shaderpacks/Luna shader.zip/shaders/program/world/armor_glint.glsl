
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

in vec2 texCoord;
flat in vec4 glColor;

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/fx/unified.glsl"
#endif

void main() {

    vec4 color = texture2D(tex, texCoord);

    color *= glColor;

    color.rgb *= glColor.a;

    #ifdef COLOR_CODED_PROGRAMS
        lu_ColorCodeProgram(color, -1);
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}

#endif

#ifdef VERTEX_SHADER

out vec2 texCoord;
flat out vec4 glColor;

void main() {

    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    glColor = gl_Color;

    #if LU_HAND_SWAYING > 0
        if (gl_ProjectionMatrix[2][2] > -0.5) {

            #if LU_HAND_SWAYING == 1
                const float handSwayMult = 0.5;
            #elif LU_HAND_SWAYING == 2
                const float handSwayMult = 1.0;
            #elif LU_HAND_SWAYING == 3
                const float handSwayMult = 2.0;
            #endif
            gl_Position.x += handSwayMult * (sin(frameTimeCounter * 0.86)) / 256.0;
            gl_Position.y += handSwayMult * (cos(frameTimeCounter * 1.5)) / 64.0;
        }
    #endif
}

#endif
