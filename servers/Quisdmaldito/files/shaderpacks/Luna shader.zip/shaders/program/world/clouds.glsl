
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

#if LU_CLOUD_STYLE_DEFINE == 50
    in vec2 texCoord;
    flat in vec3 upVec, sunVec;
    in vec4 glColor;
#endif

#if LU_CLOUD_STYLE_DEFINE == 50
    float SdotU = dot(sunVec, upVec);
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
#endif

#if LU_CLOUD_STYLE_DEFINE == 50
    #include "/lib/colors/core.glsl"
        #include "/lib/sky/globals.glsl"

    #if defined LU_TAA && defined LU_BORDER_FOG
        #include "/lib/filter/offset.glsl"
    #endif

    #ifdef ATM_COLOR_MULTS
        #include "/lib/colors/effects.glsl"
    #endif
    #ifdef MOON_PHASE_INF_ATMOSPHERE
        #include "/lib/colors/effects.glsl"
    #endif

    #ifdef COLOR_CODED_PROGRAMS
        #include "/lib/fx/unified.glsl"
    #endif
#endif

void main() {

    #if LU_CLOUD_STYLE_DEFINE != 50
        discard;
    #else

        vec4 color = texture2D(tex, texCoord) * glColor;

        vec4 translucentMult = vec4(mix(vec3(0.666), color.rgb * (1.0 - lu_pow2(lu_pow2(color.a))), color.a), 1.0);

        #ifdef OVERWORLD

            vec3 cloudLight = mix(vec3(0.8, 1.6, 1.5) * lu_sqrt1(nightFactor),
                                mix(dayDownSkyColor, dayMiddleSkyColor, 0.1), sunFactor);
            color.rgb *= sqrt(cloudLight) * (1.2 + 0.4 * noonFactor * invRainFactor);

            #if LU_CLOUD_R != 100 || LU_CLOUD_G != 100 || LU_CLOUD_B != 100
                color.rgb *= vec3(LU_CLOUD_R, LU_CLOUD_G, LU_CLOUD_B) * 0.01;
            #endif

            #ifdef ATM_COLOR_MULTS
                color.rgb *= sqrt(GetAtmColorMult());
            #endif
            #ifdef MOON_PHASE_INF_ATMOSPHERE
                color.rgb *= moonPhaseInfluence;
            #endif
        #endif

        #if defined LU_BORDER_FOG && !defined LU_DREAM_TWEAKED_BORDERFOG

            vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
            #ifdef LU_TAA
                vec3 viewPos = lu_ScreenToView(vec3(lu_TAAJitter(screenPos.xy, -0.5), screenPos.z));
            #else
                vec3 viewPos = lu_ScreenToView(screenPos);
            #endif
            vec3 playerPos = lu_ViewToPlayer(viewPos);

            float xzMaxDistance = max(abs(playerPos.x), abs(playerPos.z));
            float cloudDistance = 375.0;
            cloudDistance = clamp((cloudDistance - xzMaxDistance) / cloudDistance, 0.0, 1.0);
            color.a *= lu_clamp01(cloudDistance * 3.0);
        #endif

        #ifdef COLOR_CODED_PROGRAMS
            lu_ColorCodeProgram(color, -1);
        #endif

        /* DRAWBUFFERS:063 */
        gl_FragData[0] = color;
        gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
        gl_FragData[2] = vec4(1.0 - translucentMult.rgb, translucentMult.a);
    #endif
}

#endif

#ifdef VERTEX_SHADER

#if LU_CLOUD_STYLE_DEFINE == 50
    out vec2 texCoord;
    flat out vec3 upVec, sunVec;
    out vec4 glColor;
#endif

#if LU_CLOUD_STYLE_DEFINE == 50
    #ifdef LU_TAA
        #include "/lib/filter/offset.glsl"
    #endif
#endif

void main() {

    #if LU_CLOUD_STYLE_DEFINE != 50
        gl_Position = vec4(-1.0);
    #else

        texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

        glColor = gl_Color;

        upVec = normalize(gbufferModelView[1].xyz);
        sunVec = GetSunVector();

        vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
        gl_Position = gl_ProjectionMatrix * gbufferModelView * position;

        #ifdef LU_TAA
            gl_Position.xy = lu_TAAJitter(gl_Position.xy, gl_Position.w);
        #endif
    #endif
}

#endif
