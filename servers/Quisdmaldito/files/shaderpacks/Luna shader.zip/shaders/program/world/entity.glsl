
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

in vec2 texCoord;
in vec2 lmCoord;

flat in vec3 upVec, sunVec, northVec, eastVec;
in vec3 normal;

in vec4 glColor;

#if defined LU_GENERATED_NORMALS || defined LU_COATED_TEXTURES || defined LU_POM || defined LU_IPBR && defined IS_IRIS
    in vec2 signMidCoordPos;
    flat in vec2 absMidCoordPos;
    flat in vec2 midCoord;
#endif

#if defined LU_GENERATED_NORMALS || defined LU_CUSTOM_PBR
    flat in vec3 binormal, tangent;
#endif

#ifdef LU_POM
    in vec3 viewVector;
    in vec4 vTexCoordAM;
#endif

float NdotU = dot(normal, upVec);
float NdotUmax0 = max(NdotU, 0.0);
float SdotU = dot(sunVec, upVec);

float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;

#ifdef OVERWORLD
    vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#else
    vec3 lightVec = sunVec;
#endif

#if defined LU_GENERATED_NORMALS || defined LU_CUSTOM_PBR
    mat3 tbnMatrix = mat3(
        tangent.x, binormal.x, normal.x,
        tangent.y, binormal.y, normal.y,
        tangent.z, binormal.z, normal.z
    );
#endif

#include "/lib/sky/globals.glsl"
#include "/lib/light/core.glsl"

#if defined LU_GENERATED_NORMALS || defined LU_COATED_TEXTURES

    vec2 dcdx = dFdx(texCoord.xy);
    vec2 dcdy = dFdy(texCoord.xy);
    vec2 midCoordPos = absMidCoordPos * signMidCoordPos;

    vec2 mipx = dcdx / absMidCoordPos * 8.0;
    vec2 mipy = dcdy / absMidCoordPos * 8.0;

    float mipDelta = max(dot(mipx, mipx), dot(mipy, mipy));
    float miplevel = max(0.5 * log2(mipDelta), 0.0);

    #if !defined LU_GBUFFERS_ENTITIES && !defined LU_GBUFFERS_HAND
        vec2 atlasSizeM = atlasSize;
    #else
        vec2 atlasSizeM = atlasSize.x + atlasSize.y > 0.5 ? atlasSize : textureSize(tex, 0);
    #endif
#endif

#ifdef LU_GENERATED_NORMALS
    #include "/lib/mtl_method/normals.glsl"
#endif

#ifdef LU_COATED_TEXTURES
    #include "/lib/mtl_method/coated.glsl"
#endif

#if LU_IPBR_EMISSIVE_MODE != 1
    #include "/lib/mtl_method/emission.glsl"
#endif

#ifdef LU_CUSTOM_PBR
    #include "/lib/mtl_handle/custom.glsl"
#endif

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/fx/unified.glsl"
#endif

void main() {

    vec4 color = texture2D(tex, texCoord);
    #ifdef LU_GENERATED_NORMALS
        vec3 colorP = color.rgb;
    #endif
    color *= glColor;

    float smoothnessD = 0.0, skyLightFactor = 0.0, materialMask = OSIEBCA * 254.0;
    vec3 normalM = normal;

    float alphaCheck = color.a;
    #ifdef LU_DO_PIXELATION_EFFECTS

        alphaCheck = max(fwidth(color.a), alphaCheck);
    #endif

    if (alphaCheck > 0.001) {

        vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
        vec3 viewPos = lu_ScreenToView(screenPos);
        vec3 nViewPos = normalize(viewPos);
        vec3 playerPos = lu_ViewToPlayer(viewPos);
        float lViewPos = length(viewPos);

        bool noSmoothLighting = atlasSize.x < 600.0;
        bool noGeneratedNormals = false, noDirectionalShading = false, noVanillaAO = false;
        float smoothnessG = 0.0, highlightMult = 0.0, emission = 0.0, noiseFactor = 0.75;
        vec2 lmCoordM = lmCoord;
        vec3 shadowMult = vec3(1.0);

        #ifdef LU_IPBR
            #include "/lib/mtl_handle/entity.glsl"

            #ifdef IS_IRIS
                vec3 maRecolor = vec3(0.0);
                #include "/lib/mtl_handle/iris.glsl"
            #endif

            if (materialMask != OSIEBCA * 254.0) materialMask += OSIEBCA * 100.0;

            #ifdef LU_GENERATED_NORMALS
                if (!noGeneratedNormals) lu_GenerateNormals(normalM, colorP);
            #endif

            #ifdef LU_COATED_TEXTURES
                lu_CoatTextures(color.rgb, noiseFactor, playerPos, false);
            #endif

            #if LU_IPBR_EMISSIVE_MODE != 1
                emission = GetCustomEmissionForIPBR(color, emission);
            #endif
        #else
            #ifdef LU_CUSTOM_PBR
                lu_GetCustomMaterials(color, normalM, lmCoordM, NdotU, shadowMult, smoothnessG, smoothnessD, highlightMult, emission, materialMask, viewPos, lViewPos);
            #endif

            if (entityId == 50004) {
                #include "/lib/blocks/mob/lightning.glsl"
            } else if (entityId == 50008) {
                noSmoothLighting = true;
            } else if (entityId == 50076) {
                playerPos.y += 0.38;
            }
        #endif

        color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);

        normalM = gl_FrontFacing ? normalM : -normalM;
        vec3 geoNormal = normalM;
        vec3 worldGeoNormal = normalize(lu_ViewToPlayer(geoNormal * 10000.0));

        lu_DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, 0.5,
                   worldGeoNormal, lmCoordM, noSmoothLighting, noDirectionalShading, noVanillaAO,
                   true, 0, smoothnessG, highlightMult, emission);

        #if defined LU_IPBR && defined IS_IRIS
            color.rgb += maRecolor;
        #endif

        #ifdef LU_PBR_REFLECTIONS
            #ifdef OVERWORLD
                skyLightFactor = lu_pow2(max(lmCoord.y - 0.7, 0.0) * 3.33333);
            #else
                skyLightFactor = dot(shadowMult, shadowMult) / 3.0;
            #endif
        #endif
    }

    #ifdef COLOR_CODED_PROGRAMS
        lu_ColorCodeProgram(color, -1);
    #endif

    /* DRAWBUFFERS:06 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(smoothnessD, materialMask, skyLightFactor, 1.0);

    #if LU_BLOCK_REFLECT_QUALITY >= 2 && LU_RP_MODE >= 1

        /* DRAWBUFFERS:065 */
        gl_FragData[2] = vec4(mat3(gbufferModelViewInverse) * normalM, 1.0);
    #endif
}

#endif

#ifdef VERTEX_SHADER

out vec2 texCoord;
out vec2 lmCoord;

flat out vec3 upVec, sunVec, northVec, eastVec;
out vec3 normal;

out vec4 glColor;

#if defined LU_GENERATED_NORMALS || defined LU_COATED_TEXTURES || defined LU_POM || defined LU_IPBR && defined IS_IRIS
    out vec2 signMidCoordPos;
    flat out vec2 absMidCoordPos;
    flat out vec2 midCoord;
#endif

#if defined LU_GENERATED_NORMALS || defined LU_CUSTOM_PBR
    flat out vec3 binormal, tangent;
#endif

#ifdef LU_POM
    out vec3 viewVector;
    out vec4 vTexCoordAM;
#endif

#if defined LU_GENERATED_NORMALS || defined LU_COATED_TEXTURES || defined LU_POM || defined LU_IPBR && defined IS_IRIS
    attribute vec4 mc_midTexCoord;
#endif

#if defined LU_GENERATED_NORMALS || defined LU_CUSTOM_PBR
    attribute vec4 at_tangent;
#endif

void main() {

    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = GetLightMapCoordinates();

    lmCoord.x = min(lmCoord.x, 0.9);

    glColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);

    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    northVec = normalize(gbufferModelView[2].xyz);
    sunVec = GetSunVector();

    #if defined LU_GENERATED_NORMALS || defined LU_COATED_TEXTURES || defined LU_POM || defined LU_IPBR && defined IS_IRIS
        midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
        vec2 texMinMidCoord = texCoord - midCoord;
        signMidCoordPos = sign(texMinMidCoord);
        absMidCoordPos  = abs(texMinMidCoord);
    #endif

    #if defined LU_GENERATED_NORMALS || defined LU_CUSTOM_PBR
        binormal = normalize(gl_NormalMatrix * cross(at_tangent.xyz, gl_Normal.xyz) * at_tangent.w);
        tangent  = normalize(gl_NormalMatrix * at_tangent.xyz);
    #endif

    #ifdef LU_POM
        mat3 tbnMatrix = mat3(
            tangent.x, binormal.x, normal.x,
            tangent.y, binormal.y, normal.y,
            tangent.z, binormal.z, normal.z
        );

        viewVector = tbnMatrix * (gl_ModelViewMatrix * gl_Vertex).xyz;

        vTexCoordAM.zw  = abs(texMinMidCoord) * 2;
        vTexCoordAM.xy  = min(texCoord, midCoord - texMinMidCoord);
    #endif

    #ifdef LU_GBUFFERS_ENTITIES_GLOWING
        if (glColor.a > 0.99) gl_Position.z *= 0.01;
    #endif

    #ifdef LU_FLICKERING_FIX
        if (entityId == 50008 || entityId == 50012) {
            if (dot(normal, upVec) > 0.99) {
                vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
                vec3 comPos = fract(position.xyz + cameraPosition);
                comPos = abs(comPos - vec3(0.5));
                if ((comPos.y > 0.437 && comPos.y < 0.438) || (comPos.y > 0.468 && comPos.y < 0.469)) {
                    gl_Position.z += 0.0001;
                }
            }
            if (gl_Normal.y == 1.0) {
                normal = upVec * 2.0;
            }
        } else if (entityId == 50084) {
            gl_Position.z -= 0.00015;
        }

        #if LU_SHADOW_QUALITY == -1
            if (glColor.a < 0.5) gl_Position.z += 0.0005;
        #endif
    #endif
}

#endif
