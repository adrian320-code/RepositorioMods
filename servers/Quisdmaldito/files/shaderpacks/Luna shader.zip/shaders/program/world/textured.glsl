
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

in vec2 texCoord;
in vec2 lmCoord;

flat in vec3 upVec, sunVec;
in vec3 normal;

flat in vec4 glColor;

#ifdef LU_CLOUD_SHADOWS
    flat in vec3 eastVec;

    #if LU_SUN_ANGLE != 0
        flat in vec3 northVec;
    #endif
#endif

float NdotU = dot(normal, upVec);
float NdotUmax0 = max(NdotU, 0.0);
float SdotU = dot(sunVec, upVec);

float sunFactor = SdotU < 0.0 ?
    clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 :
    clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;

float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;

#ifdef OVERWORLD
    vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#else
    vec3 lightVec = sunVec;
#endif

#include "/lib/sky/globals.glsl"
#include "/lib/light/core.glsl"

#if MC_VERSION >= 11500
    #include "/lib/sky/aero/main.glsl"
#endif

#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/effects.glsl"
#endif

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/fx/unified.glsl"
#endif

void main() {

    vec4 color = texture2D(tex, texCoord);
    vec4 colorP = color;
    color *= glColor;

    vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
    vec3 viewPos = lu_ScreenToView(screenPos);
    float lViewPos = length(viewPos);
    vec3 playerPos = lu_ViewToPlayer(viewPos);

    float dither = texture2D(noisetex, gl_FragCoord.xy / 128.0).b;
    #ifdef LU_TAA
        dither = fract(dither + goldenRatio * mod(float(frameCounter), 3600.0));
    #endif

    #ifdef ATM_COLOR_MULTS
        atmColorMult = GetAtmColorMult();
    #endif

    #ifdef LU_VL_CLOUDS_ACTIVE
        float cloudLinearDepth = texelFetch(gaux1, texelCoord, 0).r;

        if (cloudLinearDepth > 0.0)
        if (lu_pow2(cloudLinearDepth + OSIEBCA * dither) * renderDistance < min(lViewPos, renderDistance))
            discard;
    #endif

    float emission = 0.0;
    float materialMask = OSIEBCA * 254.0;
    vec2 lmCoordM = lmCoord;
    vec3 normalM = normal, geoNormal = normal, shadowMult = vec3(1.0);
    vec3 worldGeoNormal = normalize(lu_ViewToPlayer(geoNormal * 10000.0));

    #if defined LU_IPBR && defined LU_IPBR_PARTICLE_FEATURES

        #if MC_VERSION >= 12000
            float atlasCheck = 1200.0;
        #else
            float atlasCheck = 950.0;
        #endif

        if (atlasSize.x < atlasCheck) {

            if (color.b > 1.15 * (color.r + color.g) && color.g > color.r * 1.25 &&
                color.g < 0.425 && color.b > 0.75) {
                if (color.a < 0.1) discard;

            #ifdef OVERWORLD
            } else if (color.b > 0.7 && color.r < 0.28 && color.g < 0.425 &&
                      color.g > color.r * 1.4) {
                if (color.a < 0.1 || isEyeInWater == 3) discard;
                color.a *= rainTexOpacity;
                color.rgb = lu_sqrt2(color.rgb) *
                           (blocklightCol * 2.0 * lmCoord.x +
                            ambientColor * lmCoord.y * (0.8 + 0.4 * sunFactor));

            } else if (color.rgb == vec3(1.0) && color.a < 0.765 && color.a > 0.605) {
                if (color.a < 0.1 || isEyeInWater == 3) discard;
                color.a *= snowTexOpacity;
                color.rgb = lu_sqrt2(color.rgb) *
                           (blocklightCol * 1.8 * lmCoord.x +
                            lmCoord.y * (0.75 + 0.4 * sunFactor) +
                            ambientColor * 0.25);
            #endif

            } else if (color.r == color.g && color.r - 0.5 * color.b < 0.06) {

            } else if (color.a < 0.99 && dot(color.rgb, color.rgb) < 1.0) {

            } else if (max(abs(colorP.r - colorP.b), abs(colorP.b - colorP.g)) < 0.001) {
                if (color.r > 0.83 && color.g > 0.23 && color.b < 0.4) {
                    emission = 3.0;
                    color.b *= 0.4;
                    color.r *= 1.3;
                    color.g *= 1.1;
                }
            }
        }

        bool noSmoothLighting = false;
    #else
        bool noSmoothLighting = true;
    #endif

    #ifdef LU_REDUCE_CLOSE_PARTICLES
        if (lViewPos - 1.0 < dither) discard;
    #endif

    #ifdef GLOWING_COLORED_PARTICLES
        if (atlasSize.x < 950.0) {
            if (dot(glColor.rgb, vec3(1.0)) < 2.99) {
                emission = 6.0;
            }
        }
    #endif

    lu_DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, dither,
               worldGeoNormal, lmCoordM, noSmoothLighting, false, true,
               false, 0, 0.0, 1.0, emission);

    #if MC_VERSION >= 11500
        vec3 nViewPos = normalize(viewPos);

        float VdotU = dot(nViewPos, upVec);
        float VdotS = dot(nViewPos, sunVec);
        float sky = 0.0;

        lu_DoFog(color.rgb, sky, lViewPos, playerPos, VdotU, VdotS, dither);
    #endif

    vec3 translucentMult = mix(vec3(0.666),
                              color.rgb * (1.0 - lu_pow2(lu_pow2(color.a))),
                              color.a);

    #ifdef COLOR_CODED_PROGRAMS
        lu_ColorCodeProgram(color, -1);
    #endif

    /* DRAWBUFFERS:063 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(0.0, materialMask, 0.0, 1.0);
    gl_FragData[2] = vec4(1.0 - translucentMult, 1.0);
}

#endif

#ifdef VERTEX_SHADER

out vec2 texCoord;
out vec2 lmCoord;

flat out vec3 upVec, sunVec;
out vec3 normal;

flat out vec4 glColor;

#ifdef LU_CLOUD_SHADOWS
    flat out vec3 eastVec;

    #if LU_SUN_ANGLE != 0
        flat out vec3 northVec;
    #endif
#endif

void main() {

    gl_Position = ftransform();

    texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmCoord  = GetLightMapCoordinates();

    glColor = gl_Color;

    normal = normalize(gl_NormalMatrix * gl_Normal);
    upVec = normalize(gbufferModelView[1].xyz);
    sunVec = GetSunVector();

    #ifdef LU_FLICKERING_FIX
        gl_Position.z -= 0.000002;
    #endif

    #ifdef LU_CLOUD_SHADOWS
        eastVec = normalize(gbufferModelView[0].xyz);

        #if LU_SUN_ANGLE != 0
            northVec = normalize(gbufferModelView[2].xyz);
        #endif
    #endif
}

#endif
