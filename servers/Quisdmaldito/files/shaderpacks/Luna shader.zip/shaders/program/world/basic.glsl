
#include "/lib/config/master.glsl"

#ifdef FRAGMENT_SHADER

flat in vec2 lmCoord;
flat in vec3 upVec, sunVec, northVec, eastVec;
in vec3 normal;
flat in vec4 glColor;

float NdotU = dot(normal, upVec);
float NdotUmax0 = max(NdotU, 0.0);
float SdotU = dot(sunVec, upVec);

float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
float sunVisibility2 = sunVisibility * sunVisibility;
float shadowTimeVar1 = abs(sunVisibility - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;

#ifdef OVERWORLD

    vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
#else

    vec3 lightVec = sunVec;
#endif

#include "/lib/sky/globals.glsl"
#include "/lib/light/core.glsl"

#ifdef LU_TAA
    #include "/lib/filter/offset.glsl"
#endif

#ifdef COLOR_CODED_PROGRAMS
    #include "/lib/fx/unified.glsl"
#endif

void main() {

    vec4 color = glColor;

    vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
    #ifdef LU_TAA
        vec3 viewPos = lu_ScreenToView(vec3(lu_TAAJitter(screenPos.xy, -0.5), screenPos.z));
    #else
        vec3 viewPos = lu_ScreenToView(screenPos);
    #endif

    float lViewPos = length(viewPos);
    vec3 playerPos = lu_ViewToPlayer(viewPos);

    float materialMask = 0.0;
    vec3 normalM = normal;
    vec3 geoNormal = normal;
    vec3 shadowMult = vec3(1.0);
    vec3 worldGeoNormal = normalize(lu_ViewToPlayer(geoNormal * 10000.0));

    #ifndef LU_GBUFFERS_LINE
        lu_DoLighting(color, shadowMult, playerPos, viewPos, lViewPos, geoNormal, normalM, 0.5,
                   worldGeoNormal, lmCoord, false, false, false,
                   false, 0, 0.0, 0.0, 0.0);
    #endif

    #if LU_SELECT_OUTLINE != 1 || defined SELECT_OUTLINE_AUTO_HIDE
    if (abs(color.a - 0.4) + dot(color.rgb, color.rgb) < 0.01) {
        #if LU_SELECT_OUTLINE == 0

            discard;
        #elif LU_SELECT_OUTLINE == 2

            float posFactor = playerPos.x + playerPos.y + playerPos.z + cameraPosition.x + cameraPosition.y + cameraPosition.z;
            color.rgb = clamp(abs(mod(fract(frameTimeCounter*0.25 + posFactor*0.2) * 6.0 + vec3(0.0,4.0,2.0), 6.0) - 3.0) - 1.0,
                        0.0, 1.0) * vec3(3.0, 2.0, 3.0) * LU_SELECT_OUTLINE_I;
        #elif LU_SELECT_OUTLINE == 3

            color.rgb = vec3(LU_SELECT_OUTLINE_R, LU_SELECT_OUTLINE_G, LU_SELECT_OUTLINE_B) * LU_SELECT_OUTLINE_I;
        #elif LU_SELECT_OUTLINE == 4

            color.a = 0.1;
            materialMask = OSIEBCA * 252.0;
        #endif

        #ifdef SELECT_OUTLINE_AUTO_HIDE
            if (heldItemId == 40008 && (
                heldItemId2 == 40008 ||
                heldItemId2 == 45060 ||
                heldItemId2 == 45108 ||
                heldItemId2 >= 44000 &&
                heldItemId2 < 45000)) {

                discard;
            }
        #endif
    }
    #endif

    #ifdef COLOR_CODED_PROGRAMS
        lu_ColorCodeProgram(color, -1);
    #endif

    #if LU_COLORED_LIGHTING_INTERNAL > 0 && defined NETHER
        if (gl_FragCoord.x < 0.0)
        color = shadow2D(shadowtex0, vec3(0.5));
    #endif

    /* DRAWBUFFERS:06 */
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(0.0, materialMask, 0.0, 1.0);
}

#endif

#ifdef VERTEX_SHADER

flat out vec2 lmCoord;
flat out vec3 upVec, sunVec, northVec, eastVec;
out vec3 normal;
flat out vec4 glColor;

#ifdef LU_TAA
    #include "/lib/filter/offset.glsl"
#endif

void main() {

    #ifndef LU_GBUFFERS_LINE

        gl_Position = ftransform();
    #else

        float lineWidth = 2.0;
        vec2 screenSize = vec2(viewWidth, viewHeight);
        const mat4 VIEW_SCALE = mat4(mat3(1.0 - (1.0 / 256.0)));

        vec4 linePosStart = projectionMatrix * VIEW_SCALE * modelViewMatrix * vec4(vaPosition, 1.0);
        vec4 linePosEnd = projectionMatrix * VIEW_SCALE * modelViewMatrix * (vec4(vaPosition + vaNormal, 1.0));

        vec3 ndc1 = linePosStart.xyz / linePosStart.w;
        vec3 ndc2 = linePosEnd.xyz / linePosEnd.w;

        vec2 lineScreenDirection = normalize((ndc2.xy - ndc1.xy) * screenSize);
        vec2 lineOffset = vec2(-lineScreenDirection.y, lineScreenDirection.x) * lineWidth / screenSize;

        if (lineOffset.x < 0.0)
            lineOffset *= -1.0;

        if (gl_VertexID % 2 == 0)
            gl_Position = vec4((ndc1 + vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
        else
            gl_Position = vec4((ndc1 - vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
    #endif

    #ifdef LU_TAA
        gl_Position.xy = lu_TAAJitter(gl_Position.xy, gl_Position.w);
    #endif

    lmCoord = GetLightMapCoordinates();
    glColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);

    upVec = normalize(gbufferModelView[1].xyz);
    eastVec = normalize(gbufferModelView[0].xyz);
    northVec = normalize(gbufferModelView[2].xyz);
    sunVec = GetSunVector();
}

#endif
