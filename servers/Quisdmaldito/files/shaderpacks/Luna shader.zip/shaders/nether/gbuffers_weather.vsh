#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_WEATHER

#include "/program/world/weather.glsl"
