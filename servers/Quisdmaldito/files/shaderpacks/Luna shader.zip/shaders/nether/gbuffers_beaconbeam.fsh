#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_BEACONBEAM

#include "/program/world/beacon_beam.glsl"
