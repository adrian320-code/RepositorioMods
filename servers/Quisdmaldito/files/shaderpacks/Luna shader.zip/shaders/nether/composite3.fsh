#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_COMPOSITE3

#include "/program/pass/pass3.glsl"
