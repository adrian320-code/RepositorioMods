#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_WEATHER

#include "/program/world/weather.glsl"
