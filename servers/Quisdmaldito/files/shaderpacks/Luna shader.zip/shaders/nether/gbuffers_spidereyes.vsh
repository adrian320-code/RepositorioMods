#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_SPIDEREYES

#include "/program/world/spider_eyes.glsl"
