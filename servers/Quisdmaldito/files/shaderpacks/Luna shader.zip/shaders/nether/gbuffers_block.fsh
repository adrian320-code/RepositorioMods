#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_BLOCK

#include "/program/world/block_entity.glsl"
