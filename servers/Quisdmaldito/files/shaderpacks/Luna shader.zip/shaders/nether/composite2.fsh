#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_COMPOSITE2

#include "/program/pass/pass2.glsl"
