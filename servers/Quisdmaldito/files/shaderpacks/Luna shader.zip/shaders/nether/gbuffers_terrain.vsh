#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_TERRAIN

#include "/program/world/terrain.glsl"
