#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_DAMAGED_BLOCK

#include "/program/world/damaged_block.glsl"
