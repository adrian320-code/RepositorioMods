#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_COMPOSITE4

#include "/program/pass/pass4.glsl"
