#version 130

#define VERTEX_SHADER
#define NETHER
#define DH_WATER

#include "/program/post/dh_water.glsl"
