#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_BASIC

#include "/program/world/basic.glsl"
