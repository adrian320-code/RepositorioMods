#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_ARMOR_GLINT

#include "/program/world/armor_glint.glsl"
