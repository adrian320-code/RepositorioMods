#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_TEXTURED

#include "/program/world/textured.glsl"
