#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_COMPOSITE

#include "/program/pass/pass1.glsl"
