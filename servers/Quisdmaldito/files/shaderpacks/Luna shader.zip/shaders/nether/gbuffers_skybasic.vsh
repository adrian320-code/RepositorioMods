#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_SKYBASIC

#include "/program/world/sky_basic.glsl"
