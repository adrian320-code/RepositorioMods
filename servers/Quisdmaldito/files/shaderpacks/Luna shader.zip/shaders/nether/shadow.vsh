#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_SHADOW

#include "/program/shadow.glsl"
