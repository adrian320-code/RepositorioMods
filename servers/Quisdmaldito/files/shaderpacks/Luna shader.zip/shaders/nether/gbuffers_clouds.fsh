#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
