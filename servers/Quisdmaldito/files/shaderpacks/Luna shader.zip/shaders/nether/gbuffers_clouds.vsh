#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_CLOUDS

#include "/program/world/clouds.glsl"
