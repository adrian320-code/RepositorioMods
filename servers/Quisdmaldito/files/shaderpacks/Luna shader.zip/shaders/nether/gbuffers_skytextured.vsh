#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_GBUFFERS_SKYTEXTURED

#include "/program/world/sky_textured.glsl"
