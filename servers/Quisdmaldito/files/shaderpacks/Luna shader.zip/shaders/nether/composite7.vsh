#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_COMPOSITE7

#include "/program/pass/pass7.glsl"
