#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_SHADOW

#include "/program/shadow.glsl"
