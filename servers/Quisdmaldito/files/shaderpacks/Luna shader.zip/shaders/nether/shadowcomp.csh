#version 430 compatibility

#define COMPUTE_SHADER
#define NETHER
#define LU_SHADOWCOMP

#include "/program/post/shadow_pass.glsl"
