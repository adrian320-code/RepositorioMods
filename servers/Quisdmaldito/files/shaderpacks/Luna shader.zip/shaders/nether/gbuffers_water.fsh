#version 130

#define FRAGMENT_SHADER
#define NETHER
#define LU_GBUFFERS_WATER

#include "/program/world/water.glsl"
