#version 130

#define VERTEX_SHADER
#define NETHER
#define LU_COMPOSITE6

#include "/program/pass/pass6.glsl"
