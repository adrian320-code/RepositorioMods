#ifdef OVERWORLD
    #include "/lib/sky/volumetric.glsl"
#endif
#if defined END && defined LU_DEFERRED1
    #include "/lib/sky/volumetric.glsl"
#endif

#ifdef ATM_COLOR_MULTS
    #include "/lib/colors/effects.glsl"
#endif
#ifdef MOON_PHASE_INF_ATMOSPHERE
    #include "/lib/colors/effects.glsl"
#endif

vec3 lu_nvec3(vec4 pos) {
    return pos.xyz/pos.w;
}

vec3 refPos = vec3(0.0);

#ifdef OVERWORLD
vec3 lu_GetWaterMoonReflection(vec3 reflectedViewDir) {
    vec3 nWorldDir = normalize(mat3(gbufferModelViewInverse) * reflectedViewDir);
    vec3 moonDir = normalize(vec3(0.35, 0.55, -0.75));
    float md = dot(nWorldDir, moonDir);
    float nightVis = lu_clamp01(lu_pow2(invNoonFactor2) * (1.0 - 0.65 * sunVisibility) * invRainFactor);

    float halo = smoothstep(0.925, 0.985, md);
    vec3 result = vec3(0.55, 0.16, 0.12) * halo * halo * 0.34;

    if (md > 0.985) {
        float t = (md - 0.985) / 0.015;
        float edge = smoothstep(0.0, 0.04, t);

        vec3 ortho1 = normalize(cross(moonDir, vec3(0.0, 1.0, 0.0)));
        vec3 ortho2 = cross(moonDir, ortho1);
        vec2 uv = vec2(dot(nWorldDir, ortho1), dot(nWorldDir, ortho2)) * 18.0;
        float n1 = texture2D(noisetex, uv * 0.50).r;
        float n2 = texture2D(noisetex, uv * 1.70 + 0.31).g;
        float craters = smoothstep(0.42, 0.78, n1 * 0.6 + n2 * 0.4);
        float blotch = smoothstep(0.55, 0.95, texture2D(noisetex, uv * 0.18).b);

        vec3 moonBase = vec3(0.95, 0.18, 0.12);
        vec3 moonShadow = vec3(0.22, 0.03, 0.02);
        vec3 moonCol = mix(moonBase, moonShadow, craters * 0.85);
        moonCol = mix(moonCol, moonShadow * 1.4, blotch * 0.6);
        moonCol *= 0.55 + 0.45 * t;

        result = mix(result, moonCol * 1.65, edge);
    }

    return result * nightVis;
}
#endif

vec4 lu_GetReflection(vec3 normalM, vec3 viewPos, vec3 nViewPos, vec3 playerPos, float lViewPos, float z0,
                   sampler2D depthtex, float dither, float skyLightFactor, float fresnel,
                   float smoothness, vec3 geoNormal, vec3 color, vec3 shadowMult, float highlightMult) {
    // ============================== Step 1: Prepare ============================== //
    vec2 rEdge = vec2(0.6, 0.55);
    #if defined LU_GBUFFERS_WATER || defined DH_WATER
        rEdge = vec2(0.72, 0.66);
    #endif
    vec3 normalMR = normalM;

    #if defined LU_GBUFFERS_WATER && LU_WATER_STYLE == 1 && defined LU_GENERATED_NORMALS
        normalMR = normalize(mix(geoNormal, normalM, 0.05));
    #endif

    vec3 nViewPosR = normalize(reflect(nViewPos, normalMR));
    float RVdotU = dot(nViewPosR, upVec);
    float RVdotS = dot(nViewPosR, sunVec);

    #if defined LU_GBUFFERS_WATER && LU_WATER_STYLE >= 2
        normalMR = normalize(mix(geoNormal, normalM, 0.8));
    #endif
    // ============================== End of Step 1 ============================== //

    // ============================== Step 2: Calculate Terrain Reflection and Alpha ============================== //
    vec4 reflection = vec4(0.0);
    #if defined LU_DEFERRED1 || LU_WATER_REFLECT_QUALITY >= 1
        #if defined LU_DEFERRED1 || LU_WATER_REFLECT_QUALITY >= 2 && !defined DH_WATER
            // Method 1: Ray Marched Reflection //

            // Ray Marching
            vec3 start = viewPos + normalMR * (lViewPos * 0.025 * (1.0 - fresnel) + 0.05);
            #if defined LU_GBUFFERS_WATER && LU_WATER_STYLE >= 2
                vec3 vector = normalize(reflect(nViewPos, normalMR)); // Not using nViewPosR because normalMR changed
            #else
                vec3 vector = nViewPosR;
            #endif
            //vector = normalize(vector - 0.5 * (1.0 - smoothness) * (1.0 - fresnel) * normalMR); // reflection anisotropy test
            //vector = normalize(vector - 0.075 * dither * (1.0 - lu_pow2(lu_pow2(fresnel))) * normalMR);
            vector *= 0.5;
            vec3 viewPosRT = viewPos + vector;
            vec3 tvector = vector;

            int sr = 0;
            float dist = 0.0;
            vec3 rfragpos = vec3(0.0);
            for (int i = 0; i < 30; i++) {
                refPos = lu_nvec3(gbufferProjection * vec4(viewPosRT, 1.0)) * 0.5 + 0.5;
                if (abs(refPos.x - 0.5) > rEdge.x || abs(refPos.y - 0.5) > rEdge.y) break;

                rfragpos = vec3(refPos.xy, texture2D(depthtex, refPos.xy).r);
                rfragpos = lu_nvec3(gbufferProjectionInverse * vec4(rfragpos * 2.0 - 1.0, 1.0));
                dist = length(start - rfragpos);

                float err = length(viewPosRT - rfragpos);

                if (err < length(vector) * 3.0) {
                    sr++;
                    if (sr >= 6) break;
                    tvector -= vector;
                    vector *= 0.1;
                }
                vector *= 2.0;
                tvector += vector * (0.95 + 0.1 * dither);
                viewPosRT = start + tvector;
            }

            // Finalizing Terrain Reflection and Alpha
            if (refPos.z < 0.99997) {
                vec2 absPos = abs(refPos.xy - 0.5);
                vec2 cdist = absPos / rEdge;
                float border = clamp(1.0 - pow(max(cdist.x, cdist.y), 50.0), 0.0, 1.0);
                reflection.a = border;

                float lViewPosRT = length(rfragpos);

                if (reflection.a > 0.001) {
                    vec2 edgeFactor = lu_pow2(lu_pow2(lu_pow2(cdist)));
                    refPos.y += (dither - 0.5) * (0.05 * (edgeFactor.x + edgeFactor.y));

                    #ifdef LU_DEFERRED1
                        float smoothnessDM = lu_pow2(smoothness);
                        float lodFactor = 1.0 - exp(-0.125 * (1.0 - smoothnessDM) * dist);
                        float lod = log2(viewHeight / 8.0 * (1.0 - smoothnessDM) * lodFactor) * 0.45;
                        if (z0 <= 0.56) lod *= 2.22; // Using more lod to compensate for less roughness noise on held items
                        lod = max(lod - 1.0, 0.0);

                        reflection.rgb = texture2DLod(colortex0, refPos.xy, lod).rgb;
                    #else
                        // (x+1)^2 - 1 = x*(x+2): original formula minus the constant floor of 1.
                        // f(0)=0 (dark night sky stays dark), f(0.5)=1.25, f(0.7)=1.89 (terrain stays bright).
                        reflection = texture2D(gaux2, refPos.xy);
                        reflection.rgb = reflection.rgb * (reflection.rgb + 2.0);
                    #endif

                    float skyFade = 0.0;
                    lu_DoFog(reflection.rgb, skyFade, lViewPosRT, lu_ViewToPlayer(rfragpos.xyz), RVdotU, RVdotS, dither);

                    edgeFactor.x = lu_pow2(edgeFactor.x);
                    edgeFactor = 1.0 - edgeFactor;
                    #if defined LU_GBUFFERS_WATER || defined DH_WATER
                        reflection.a *= pow(edgeFactor.x * edgeFactor.y, 0.85 + 0.75 * lu_GetLuminance(reflection.rgb));
                        reflection.a = clamp(reflection.a * 2.15, 0.0, 1.0);
                    #else
                        reflection.a *= pow(edgeFactor.x * edgeFactor.y, 2.0 + 3.0 * lu_GetLuminance(reflection.rgb));
                    #endif
                }

                float posDif = lViewPosRT - lViewPos;
                reflection.a *= clamp(posDif + 3.0, 0.0, 1.0);
            }
            #if defined LU_DEFERRED1 && defined LU_TEMPORAL_FILTER
                else refPos.z = 1.0;
            #endif
            #if !defined LU_DEFERRED1 && defined DISTANT_HORIZONS
                else
            #endif
        #endif
        #if !defined LU_DEFERRED1 && (LU_WATER_REFLECT_QUALITY < 2 || defined DISTANT_HORIZONS) || defined DH_WATER
        {   // Method 2: Mirorred Image Reflection //

            #if LU_WATER_REFLECT_QUALITY < 2
                float verticalStretch = 0.013; // for potato quality reflections
            #else
                float verticalStretch = 0.0025; // for distant horizons reflections
            #endif

            vec4 clipPosR = gbufferProjection * vec4(nViewPosR + verticalStretch * viewPos, 1.0);
            vec3 screenPosR = clipPosR.xyz / clipPosR.w * 0.5 + 0.5;
            vec2 screenPosRM = abs(screenPosR.xy - 0.5);

            if (screenPosRM.x < rEdge.x && screenPosRM.y < rEdge.y) {
                vec2 edgeFactor = lu_pow2(lu_pow2(lu_pow2(screenPosRM / rEdge)));
                screenPosR.y += (dither - 0.5) * (0.03 * (edgeFactor.x + edgeFactor.y) + 0.004);

                screenPosR.z = texture2D(depthtex1, screenPosR.xy).x;
                vec3 viewPosR = lu_ScreenToView(screenPosR);
                if (lViewPos <= 2.0 + length(viewPosR)) {
                    // (x+1)^2 - 1 = x*(x+2): same decode as Method 1.
                    reflection = texture2D(gaux2, screenPosR.xy);
                    reflection.rgb = reflection.rgb * (reflection.rgb + 2.0);
                }

                edgeFactor.x = lu_pow2(edgeFactor.x);
                edgeFactor = 1.0 - edgeFactor;
                reflection.a *= edgeFactor.x * edgeFactor.y;
            }

            reflection.a *= reflection.a;
            reflection.a *= lu_clamp01((dot(nViewPos, nViewPosR) - 0.45) * 10.0); // Fixes perpendicular ref
        }
        #endif
    #endif
    // ============================== End of Step 2 ============================== //

    // ============================== Step 3: Add Sky Reflection ============================== //
    #if defined LU_DEFERRED1 || LU_WATER_REFLECT_QUALITY >= 1
        if (reflection.a < 1.0)
    #endif
    {
        #ifdef OVERWORLD
            #if defined LU_GBUFFERS_WATER || defined DH_WATER
                float waterSkyNight = lu_clamp01(lu_pow2(invNoonFactor2) * (1.0 - 0.45 * sunVisibility));
                vec3 skyReflection = mix(vec3(0.020, 0.040, 0.075), vec3(0.26, 0.46, 0.68), sunFactor);
                skyReflection *= 0.32 + 0.56 * skyLightFactor;
                skyReflection = mix(color * 0.22, skyReflection, 0.72);
                skyReflection += nightUpSkyColor * waterSkyNight * (0.22 + 0.30 * skyLightFactor);
            #elif defined LU_DEFERRED1 || LU_WATER_REFLECT_QUALITY >= 2
                vec3 skyReflection = LU_GetSky(RVdotU, RVdotS, dither, true, true);
            #else
                vec3 skyReflection = LU_GetLowQualitySky(RVdotU, RVdotS, dither, true, true);
            #endif

            #ifdef ATM_COLOR_MULTS
                skyReflection *= atmColorMult;
            #endif
            #ifdef MOON_PHASE_INF_ATMOSPHERE
                skyReflection *= moonPhaseInfluence;
            #endif

            #ifdef LU_DEFERRED1
                skyReflection *= skyLightFactor;
            #else
                float specularHighlight = lu_GGX(normalM, nViewPos, lightVec, max(dot(normalM, lightVec), 0.0), smoothness);
                #if defined LU_GBUFFERS_WATER || defined DH_WATER
                    vec3 waterSpecVisibility = max(shadowMult, vec3(skyLightFactor * 0.40));
                    skyReflection += specularHighlight * highlightColor * waterSpecVisibility * highlightMult * mix(0.28, 0.82, invRainFactor);
                #else
                    skyReflection += specularHighlight * highlightColor * shadowMult * highlightMult * invRainFactor;
                #endif

                #if LU_WATER_REFLECT_QUALITY >= 1
                    #ifdef LU_SKY_EFFECT_REFLECTION
                        float cloudLinearDepth = 1.0;
                        float skyFade = 1.0;
                        vec3 auroraBorealis = vec3(0.0);
                        vec3 nightNebula = vec3(0.0);

                        #if LU_AURORA_STYLE > 0
                            auroraBorealis = lu_GetAuroraBorealis(nViewPosR, RVdotU, dither);
                            skyReflection += auroraBorealis;
                        #endif
                        #ifdef NIGHT_NEBULA
                            nightNebula += lu_GetNightNebula(nViewPosR, RVdotU, RVdotS);
                            skyReflection += nightNebula;
                        #endif

                        vec2 starCoord = lu_GetStarCoord(nViewPosR, 0.5);
                        skyReflection += lu_GetStars(starCoord, RVdotU, RVdotS) * 1.55;

                        #ifdef LU_GIANT_PLANET
                            skyReflection += lu_GetGiantPlanet(nViewPosR, RVdotU, RVdotS) * 2.25;
                        #endif

                        skyReflection += lu_GetWaterMoonReflection(nViewPosR);

                        #ifdef LU_VL_CLOUDS_ACTIVE
                            #if !defined LU_GBUFFERS_WATER && !defined DH_WATER
                                vec3 worldNormalMR = normalize(mat3(gbufferModelViewInverse) * normalMR);
                                vec3 RCameraPos = cameraPosition + 2.0 * worldNormalMR * dot(playerPos, worldNormalMR);
                                vec3 RPlayerPos = normalize(mat3(gbufferModelViewInverse) * nViewPosR);
                                float RlViewPos = 100000.0;

                                float reflectionCloudDither = lu_GetStableVolumetricDither();
                                vec4 clouds = LU_GetClouds(cloudLinearDepth, skyFade, RCameraPos, RPlayerPos,
                                                        RlViewPos, RVdotS, RVdotU, reflectionCloudDither, auroraBorealis, nightNebula);

                                skyReflection = mix(skyReflection, clouds.rgb, clouds.a);
                            #endif
                        #endif
                    #endif

                    #if defined LU_GBUFFERS_WATER || defined DH_WATER
                        skyReflection = max(skyReflection, color * 0.16);
                    #else
                        skyReflection = mix(color * 0.50, skyReflection, skyLightFactor * mix(0.82, 1.0, invRainFactor));
                    #endif
                #else
                    skyReflection = mix(color, skyReflection, skyLightFactor * 0.5);
                #endif
            #endif
        #elif defined END
            #ifdef LU_DEFERRED1
                vec3 skyReflection = (endSkyColor + 0.4 * lu_DrawEnderBeams(RVdotU, playerPos)) * skyLightFactor;
            #else
                vec3 skyReflection = endSkyColor * shadowMult;
            #endif

            #ifdef ATM_COLOR_MULTS
                skyReflection *= atmColorMult;
            #endif
        #else
            vec3 skyReflection = vec3(0.0);
        #endif

        #if defined LU_GBUFFERS_WATER || defined DH_WATER
            float sceneReflectionAlpha = clamp(reflection.a * 1.35, 0.0, 1.0);
            float skyReflectionLum = lu_GetLuminance(skyReflection);
            float skyBurnLimit = mix(0.72, 1.36, sunFactor);
            skyBurnLimit = mix(skyBurnLimit, 0.72 + 0.24 * sunVisibility, rainFactor * max(inRainy, 0.35));
            skyReflection *= min(1.0, skyBurnLimit / max(skyReflectionLum, 0.001));
            reflection.rgb = mix(skyReflection, reflection.rgb, sceneReflectionAlpha);
            // Hard floor: water can never reflect darker than 60% of the sky fallback.
            // This kills black patches from shadowed/dark terrain hit by SSR at grazing angles.
            reflection.rgb = max(reflection.rgb, skyReflection * 0.60);
        #else
            reflection.rgb = mix(skyReflection, reflection.rgb, reflection.a);
        #endif
    }
    // ============================== End of Step 3 ============================== //

    return reflection;
}
