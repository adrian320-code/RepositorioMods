#if LU_COLORED_LIGHTING_INTERNAL > 0
    #include "/lib/fx/unified.glsl"
#endif

vec3 lu_GetRawWave(in vec3 pos, float wind) {
    float magnitude = sin(wind * 0.0027 + pos.z + pos.y) * 0.04 + 0.04;
    float d0 = sin(wind * 0.0127);
    float d1 = sin(wind * 0.0089);
    float d2 = sin(wind * 0.0114);
    vec3 wave;
    wave.x = sin(wind*0.0063 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
    wave.z = sin(wind*0.0224 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
    wave.y = sin(wind*0.0015 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;

    return wave;
}

vec3 lu_GetWave(in vec3 pos, float waveSpeed) {
    float wind = frameTimeCounter * waveSpeed * LU_WAVING_SPEED;
    vec3 wave = lu_GetRawWave(pos, wind);

    #define LU_WAVING_I_RAIN_MULT_M LU_WAVING_I_RAIN_MULT * 0.01

    #if LU_WAVING_I_RAIN_MULT > 100
        float windRain = frameTimeCounter * waveSpeed * LU_WAVING_I_RAIN_MULT_M * LU_WAVING_SPEED;
        vec3 waveRain = lu_GetRawWave(pos, windRain);
        wave = mix(wave, waveRain, rainFactor);
    #endif

    #ifdef LU_NO_WAVING_INDOORS
        wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
    #else
        wave *= 0.1;
    #endif

    float wavingIntensity = LU_WAVING_I * mix(1.0, LU_WAVING_I_RAIN_MULT_M, rainFactor);

    return wave * wavingIntensity;
}

void lu_DoWave_Foliage(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos.y *= 0.5;

    vec3 wave = lu_GetWave(worldPos, 170.0);
    wave.x = wave.x * 8.0 + wave.y * 4.0;
    wave.y = 0.0;
    wave.z = wave.z * 3.0;

    playerPos.xyz += wave * waveMult;
}

void lu_DoWave_Leaves(inout vec3 playerPos, vec3 worldPos, float waveMult) {
    worldPos *= vec3(0.75, 0.375, 0.75);

    vec3 wave = lu_GetWave(worldPos, 170.0);
    wave *= vec3(8.0, 3.0, 4.0);

    wave *= 1.0 - inSnowy; // Leaves with snow on top look wrong

    playerPos.xyz += wave * waveMult;
}

void lu_DoWave_Water(inout vec3 playerPos, vec3 worldPos) {
    float weatherWave = lu_clamp01(rainFactor * max(inRainy, 0.35));
    float waterWaveTime = frameTimeCounter * (5.4 + 2.6 * weatherWave) * LU_WAVING_SPEED;
    vec2 waterPlane = worldPos.xz * mix(11.0, 16.0, weatherWave);

    float swell  = sin(waterWaveTime * 0.58 + waterPlane.x * 0.125 + waterPlane.y * 0.052);
          swell += sin(waterWaveTime * 0.44 - waterPlane.x * 0.044 + waterPlane.y * 0.112) * 0.72;
    float chop   = sin(waterWaveTime * 1.18 + waterPlane.x * 0.310 - waterPlane.y * 0.210);
          chop  += sin(waterWaveTime * 0.86 - waterPlane.x * 0.180 - waterPlane.y * 0.265);
    float wave = swell + chop * (0.18 + 0.34 * weatherWave);

    #ifdef LU_NO_WAVING_INDOORS
        wave *= clamp(lmCoord.y - 0.87, 0.0, 0.1);
    #else
        wave *= 0.1;
    #endif

    playerPos.y += wave * mix(0.090, 0.155, weatherWave) - mix(0.038, 0.060, weatherWave);

    #if defined LU_GBUFFERS_WATER && LU_WATER_STYLE == 1
        normal = mix(normal, tangent, wave * 0.01);
    #endif
}

void lu_DoWave_Lava(inout vec3 playerPos, vec3 worldPos) {
    if (fract(worldPos.y + 0.005) > 0.06) {
        float lavaWaveTime = frameTimeCounter * 3.0 * LU_WAVING_SPEED;
        worldPos.xz *= 14.0;

        float wave  = sin(lavaWaveTime * 0.7 + worldPos.x * 0.14 + worldPos.z * 0.07);
              wave += sin(lavaWaveTime * 0.5 + worldPos.x * 0.05 + worldPos.z * 0.10);

        playerPos.y += wave * 0.0125;
    }
}

void lu_DoWave(inout vec3 playerPos, int mat) {
    vec3 worldPos = playerPos.xyz + cameraPosition.xyz;

    #if defined LU_GBUFFERS_TERRAIN || defined LU_SHADOW
        #ifdef LU_WAVING_FOLIAGE
            if (mat == 10005
                #ifdef LU_DO_MORE_FOLIAGE_WAVING
                    || mat == 10769
                    || mat == 10924
                    || mat == 10972
                #endif
            ) { // Grounded Waving Foliage
                if (gl_MultiTexCoord0.t < mc_midTexCoord.t || fract(worldPos.y + 0.21) > 0.26)
                lu_DoWave_Foliage(playerPos.xyz, worldPos, 1.0);
            }

            else if (mat == 10021) { // Upper Layer Waving Foliage
                lu_DoWave_Foliage(playerPos.xyz, worldPos, 1.0);
            }

            #if defined LU_WAVING_LEAVES || defined LU_WAVING_LAVA || defined LU_WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef LU_WAVING_LEAVES
            if (mat == 10009) { // Leaves
                lu_DoWave_Leaves(playerPos.xyz, worldPos, 1.0);
            } else if (mat == 10013) { // Vine
                // Reduced waving on vines to prevent clipping through blocks
                lu_DoWave_Leaves(playerPos.xyz, worldPos, 0.75);
            }
            #if defined NETHER || defined LU_DO_NETHER_VINE_WAVING_OUTSIDE_NETHER
                else if (mat == 10884 || mat == 10885) { // Weeping Vines, Twisting Vines
                    float waveMult = 1.0;
                    #if LU_COLORED_LIGHTING_INTERNAL > 0
                        vec3 playerPosP = playerPos + vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosP = SceneToVoxel(playerPosP);
                        vec3 playerPosN = playerPos - vec3(0.0, 0.1, 0.0);
                        vec3 voxelPosN = SceneToVoxel(playerPosN);

                        if (CheckInsideVoxelVolume(voxelPosP)) {
                            int voxelP = int(texelFetch(voxel_sampler, ivec3(voxelPosP), 0).r);
                            int voxelN = int(texelFetch(voxel_sampler, ivec3(voxelPosN), 0).r);
                            if (voxelP != 0 && voxelP != 65 || voxelN != 0 && voxelN != 65) // not air, not weeping vines
                                waveMult = 0.0;
                        }
                    #endif
                    lu_DoWave_Foliage(playerPos.xyz, worldPos, waveMult);
                }
            #endif

            #if defined LU_WAVING_LAVA || defined LU_WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef LU_WAVING_LAVA
            if (mat == 10068) { // Lava
                lu_DoWave_Lava(playerPos.xyz, worldPos);

                #ifdef LU_GBUFFERS_TERRAIN
                    // G8FL735 Fixes Optifine-Iris parity. Optifine has 0.9 gl_Color.rgb on a lot of versions
                    glColorRaw.rgb = min(glColorRaw.rgb, vec3(0.9));
                #endif
            }

            #ifdef LU_WAVING_LILY_PAD
                else
            #endif
        #endif

        #ifdef LU_WAVING_LILY_PAD
            if (mat == 10489) { // Lily Pad
                lu_DoWave_Water(playerPos.xyz, worldPos);
            }
        #endif
    #endif

    #if defined LU_GBUFFERS_WATER || defined LU_SHADOW
        #ifdef LU_WAVING_WATER_VERTEX
            #if defined LU_WAVING_ANYTHING_TERRAIN && defined LU_SHADOW
                else
            #endif

            if (mat == 32000) { // Water
                if (fract(worldPos.y + 0.005) > 0.06)
                lu_DoWave_Water(playerPos.xyz, worldPos);
            }
        #endif
    #endif
}
