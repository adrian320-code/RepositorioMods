#ifndef LU_INCLUDE_CUSTOM_EMISSION
#define LU_INCLUDE_CUSTOM_EMISSION

float lu_GetCustomEmission(vec4 specularMap, vec2 texCoordM) {
    #if LU_CUSTOM_EMISSION_INTENSITY > 0
        #if LU_RP_MODE == 2 || LU_RP_MODE == 1 && LU_IPBR_EMISSIVE_MODE == 2 // seuspbr
            float emission = specularMap.b;
        #elif LU_RP_MODE == 3 || LU_RP_MODE == 1 && LU_IPBR_EMISSIVE_MODE == 3 // labPBR
            float emission = specularMap.a < 1.0 ? specularMap.a : 0.0;

            vec4 specularMapL0 = texture2DLod(specular, texCoordM, 0);
            float emissionL0 = specularMapL0.a < 1.0 ? specularMapL0.a : 0.0;
            emission = min(emission, emissionL0); // Fixes issues caused by mipmaps
        #endif

        return emission * 0.03 * LU_CUSTOM_EMISSION_INTENSITY;
    #else
        return 0.0;
    #endif
}

#ifdef LU_IPBR
    float GetCustomEmissionForIPBR(inout vec4 color, float emission) {
        vec4 specularMapCheck = texture2DLod(specular, texCoord, 1000.0);
        if (specularMapCheck.a == 0.0) return emission;

        color = texture2D(tex, texCoord);

        vec4 specularMap = texture2D(specular, texCoord);
        float customEmission = lu_GetCustomEmission(specularMap, texCoord);
        return customEmission;
    }
#endif

#endif //LU_INCLUDE_CUSTOM_EMISSION
