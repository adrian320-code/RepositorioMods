/*
 * =======================================================================================
 *
 * LIQUID EFFECTS SYSTEM MODULE
 * Lunara Shader - Underwater & Liquid Rendering
 *
 * =======================================================================================
 *
 * Copyright (c) 2025 Lunara Development
 * All rights reserved. Unauthorized reproduction or distribution is prohibited.
 *
 * This module implements liquid environment effects including underwater fog,
 * distance-based opacity calculations, and quality-adaptive rendering for various
 * liquid mediums including water, lava, and other fluid substances.
 *
 * =======================================================================================
 */

#ifndef LU_INCLUDE_LIQUID_EFFECTS
#define LU_INCLUDE_LIQUID_EFFECTS

//=======================================================================================
// LIQUID EFFECTS CALCULATION FUNCTION
//=======================================================================================

/**
 * Calculates liquid environment effects based on viewing distance and quality settings
 * @param lViewPos: Current viewing distance for liquid effect calculation
 * @return: Liquid effect intensity [0.0, 1.0] where:
 * - 0.0 = No liquid effects (clear visibility)
 * - 1.0 = Maximum liquid effects (heavy fog/distortion)
 *
 * Features:
 * - Quality-adaptive distance scaling
 * - effects with light shaft rendering
 * - Exponential falloff for realistic liquid density
 */
float lu_GetLiquidEffects(float lViewPos)
{
    // Apply user-defined liquid effect intensity multiplier
    #if LU_WATER_FOG_MULT != 100
        #define LU_WATER_FOG_MULT_M LU_WATER_FOG_MULT * 0.01;
        lViewPos *= LU_WATER_FOG_MULT_M;
    #endif

    float liquidDensity;

    // Quality-based liquid effect calculation
    #if LU_LIGHTSHAFT_QUALI > 0 && LU_SHADOW_QUALITY > -1
        // === HIGH QUALITY MODE ===
        // liquid effects with light shaft integration
        // Shorter effective range with squared falloff for more dramatic effects
        liquidDensity = lViewPos / 48.0;
        liquidDensity *= liquidDensity;  // Quadratic falloff for realism

    #else
        // === STANDARD QUALITY MODE ===
        // Optimized liquid effects for performance
        // Linear falloff with extended range for smoother transitions
        liquidDensity = lViewPos / 32.0;
    #endif

    // Apply exponential liquid density calculation
    // This creates realistic liquid medium effects with natural falloff
    return 1.0 - exp(-liquidDensity);
}

//=======================================================================================
// LEGACY COMPATIBILITY
//=======================================================================================

// Maintain backward compatibility with existing water fog systems
#define LU_GetWaterFog lu_GetLiquidEffects

#endif // LU_INCLUDE_LIQUID_EFFECTS
