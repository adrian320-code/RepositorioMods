/*
 * =======================================================================================
 *
 * LIGHT LU_BLOOM EFFECTS MODULE
 * Lunara Shader - Bloom Processing
 *
 * =======================================================================================
 *
 * Copyright (c) 2025 Lunara Development
 * All rights reserved. Unauthorized reproduction or distribution is prohibited.
 *
 * This module implements light bloom effects that adapt to environmental
 * conditions including weather, time of day, dimension, and underwater states.
 * Provides visual depth and atmospheric immersion.
 *
 * =======================================================================================
 */

//=======================================================================================
// DEPENDENCIES
//=======================================================================================

#ifdef LU_CAVE_FOG
    #include "/lib/sky/aero/depth.glsl"
#endif

//=======================================================================================
// LU_BLOOM INTENSITY CONSTANTS
//=======================================================================================

/**
 * Environmental bloom intensity modifiers
 * These values control how strongly bloom effects appear in different conditions
 */
const float rainBloomIntensity     = 8.0;    // bloom during rainfall
const float nightBloomIntensity    = 3.0;    // Subtle bloom enhancement at night
const float caveBloomIntensity     = 14.0;   // Strong bloom for underground visibility
const float waterBloomIntensity    = 14.0;   // Pronounced underwater bloom effects

// Dimensional bloom configuration
#ifdef LU_BORDER_FOG
    const float netherBloomIntensity = 14.0;  // Nether bloom with border fog
#else
    const float netherBloomIntensity = 3.0;   // Standard Nether bloom intensity
#endif

//=======================================================================================
// LU_BLOOM CALCULATION FUNCTION
//=======================================================================================

/**
 * Calculates adaptive light bloom effects based on viewing distance and environment
 * @param lViewPos: Current viewing distance for bloom calculation
 * @return: Bloom multiplier value (1.0 = no bloom, >1.0 = bloom enhancement)
 */
float lu_GetLightBloom(float lViewPos)
{
    float bloomEffect;
    float bloomMultiplier;

    #ifdef OVERWORLD
        // === OVERWORLD LU_BLOOM PROCESSING ===

        // Calculate base bloom using exponential distance falloff
        // underwater detection for realistic refraction effects
        float underwaterModifier = 0.02 + 0.04 * float(isEyeInWater == 1);
        bloomEffect = lu_pow2(lu_pow2(1.0 - exp(-lViewPos * underwaterModifier)));

        // Determine bloom intensity based on environmental conditions
        if (isEyeInWater != 1) {
            // === SURFACE CONDITIONS ===

            // Weather-based bloom enhancement
            float weatherBloom = rainFactor2 * rainBloomIntensity;

            // Time-of-day bloom adjustment (stronger at night)
            float timeBloom = nightBloomIntensity * (1.0 - sunFactor);

            // Combine weather and time effects with brightness modulation
            bloomMultiplier = (weatherBloom + timeBloom) * eyeBrightnessM;

            // Add underground/cave bloom enhancement
            #ifdef LU_CAVE_FOG
                bloomMultiplier += LU_GetCaveFactor() * caveBloomIntensity;
            #endif

        } else {
            // === UNDERWATER CONDITIONS ===
            bloomMultiplier = waterBloomIntensity;
        }

    #elif defined NETHER
        // === NETHER DIMENSION LU_BLOOM PROCESSING ===

        // Calculate Nether-specific viewing distance with limits
        float netherViewLimit = min(renderDistance, LU_NETHER_VIEW_LIMIT);

        // Apply cubic falloff for dramatic Nether atmosphere
        bloomEffect = lViewPos / clamp(netherViewLimit, 96.0, 256.0);
        bloomEffect = bloomEffect * bloomEffect * bloomEffect;  // Cubic falloff

        // Apply exponential bloom with intensity
        bloomEffect = 1.0 - exp(-8.0 * bloomEffect);

        // Disable bloom when underwater in Nether (rare but handled)
        bloomEffect *= float(isEyeInWater == 0);

        // Apply Nether-specific bloom intensity
        bloomMultiplier = netherBloomIntensity;

    #endif

    // Apply global bloom strength scaling and intensity normalization
    bloomMultiplier *= LU_BLOOM_STRENGTH * 8.33333;

    // Return final bloom factor (1.0 + bloom enhancement)
    return 1.0 + bloomEffect * bloomMultiplier;
}

//=======================================================================================
// LEGACY COMPATIBILITY
//=======================================================================================

// Maintain backward compatibility with existing bloom systems
#define LU_GetBloomFog lu_GetLightBloom
