smoothnessG = lu_pow2(color.r * 2.0);
smoothnessG = lu_min1(smoothnessG);
highlightMult = smoothnessG * 2.0;
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.33;
#endif
