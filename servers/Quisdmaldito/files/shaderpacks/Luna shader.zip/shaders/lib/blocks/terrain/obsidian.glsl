materialMask = OSIEBCA; // Intense Fresnel

float factor = lu_max0(0.3 - abs(color.r - 0.3)) * 1.5;

smoothnessG = factor;
highlightMult = 2.0 + lu_min1(smoothnessG * 2.0) * 1.5;
smoothnessG = lu_min1(smoothnessG);

smoothnessD = lu_min1(factor + 0.07);

#ifdef LU_COATED_TEXTURES
    noiseFactor = 1.25;
#endif
