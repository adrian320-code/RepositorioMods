// ============================== Step 1: Color Prep ============================== //
#if MC_VERSION >= 11300
    #if LU_WATERCOLOR_MODE >= 2
        vec3 glColorM = glColor.rgb;

        #if LU_WATERCOLOR_MODE >= 3
            glColorM.g = max(glColorM.g, 0.39);
        #endif

        #ifdef LU_GBUFFERS_WATER
            translucentMultCalculated = true;
            translucentMult.rgb = normalize(lu_sqrt2(glColor.rgb));
            translucentMult.g *= 0.88;
        #endif

        glColorM = lu_sqrt1(glColorM) * vec3(1.0, 0.85, 0.8);
    #else
        vec3 glColorM = vec3(0.43, 0.6, 0.8);
    #endif

    #if LU_WATER_STYLE < 3
        vec3 colorPM = lu_pow2(colorP.rgb);
        color.rgb = colorPM * glColorM;
    #else
        vec3 colorPM = vec3(0.25);
        color.rgb = 0.375 * glColorM;
    #endif
#else
    #if LU_WATER_STYLE < 3
        color.rgb = mix(color.rgb, vec3(lu_GetLuminance(color.rgb)), 0.88);
        color.rgb = lu_pow2(color.rgb) * vec3(2.3, 3.5, 3.1) * 0.9;
    #else
        color.rgb = vec3(0.13, 0.2, 0.27);
    #endif
#endif

#ifdef LU_WATERCOLOR_CHANGED
    color.rgb *= vec3(LU_WATERCOLOR_RM, LU_WATERCOLOR_GM, LU_WATERCOLOR_BM);
#endif

// ============================== Adaptive Professional Water Tint ============================== //
{
    float luWaterDay = lu_clamp01(sunVisibility);
    float luWaterNight = lu_clamp01(nightFactor);
    float luWaterRain = lu_clamp01(rainFactor * max(inRainy, 0.35));
    float luWaterMorningEvening = lu_clamp01((1.0 - abs(sunVisibility - 0.5) * 2.0) * (1.0 - luWaterRain * 0.35));
    float luWaterSky = lu_clamp01(lmCoord.y);

    vec3 luWaterNoonTint = vec3(0.035, 0.300, 0.590);
    vec3 luWaterHorizonTint = vec3(0.105, 0.455, 0.545);
    vec3 luWaterNightTint = vec3(0.012, 0.044, 0.118);
    vec3 luWaterRainTint = vec3(0.038, 0.112, 0.155);
    vec3 luWaterShallowTint = vec3(0.180, 0.675, 0.620);

    vec3 luWaterEnvTint = mix(luWaterNightTint, luWaterNoonTint, luWaterDay);
    luWaterEnvTint = mix(luWaterEnvTint, luWaterHorizonTint, luWaterMorningEvening * 0.65);
    luWaterEnvTint = mix(luWaterEnvTint, luWaterRainTint, luWaterRain * 0.78);

    color.rgb = mix(color.rgb, luWaterEnvTint, 0.74);
    color.rgb += luWaterShallowTint * (0.035 + 0.055 * luWaterDay) * luWaterSky * (1.0 - luWaterRain);
    color.rgb *= mix(0.78 + 0.14 * luWaterNight, 1.18, luWaterDay);
    color.rgb *= mix(1.0, 0.72, luWaterRain);
}
// ============================== End of Step 1 ============================== //

#define LU_PHYSICS_OCEAN_INJECTION
#if defined LU_GENERATED_NORMALS && (LU_WATER_STYLE >= 2 || defined PHYSICS_OCEAN) && !defined DH_WATER
    noGeneratedNormals = true;
#endif

#if defined LU_GBUFFERS_WATER || defined DH_WATER
    lmCoordM.y = min(lmCoord.y * 1.07, 1.0); // Iris/Sodium skylight inconsistency workaround

    float fresnel2 = lu_pow2(fresnel);
    float fresnel4 = lu_pow2(fresnel2);

    // ============================== Step 2: Water Normals ============================== //
    reflectMult = 1.0;

    #if LU_WATER_MAT_QUALITY >= 3
        materialMask = OSIEBCA * 241.0; // Water
    #endif

    #if LU_WATER_MAT_QUALITY >= 2 || LU_WATER_STYLE >= 2
        #define LU_WATER_SPEED_MULT_M LU_WATER_SPEED_MULT * 0.018
        float weatherWave = lu_clamp01(rainFactor * max(inRainy, 0.35));
        float rawWind = frameTimeCounter * LU_WATER_SPEED_MULT_M * mix(1.0, 1.85, weatherWave);
        vec2 wind = vec2(rawWind, rawWind * (0.18 + 0.16 * weatherWave));
        vec3 worldPos = playerPos + cameraPosition;
        vec2 waterPos = worldPos.xz;
        #if LU_WATER_STYLE < 3 && defined LU_GBUFFERS_WATER
            float blockRes = absMidCoordPos.x * atlasSize.x * 2.0;
            waterPos = floor(waterPos * blockRes) / blockRes;
        #endif
        waterPos = 0.032 * (waterPos + worldPos.y * 2.0);
    #endif

    #if LU_WATER_STYLE >= 2 || LU_RAIN_PUDDLES >= 1 && LU_WATER_STYLE == 1 && LU_WATER_MAT_QUALITY >= 2
        vec3 normalMap = vec3(0.0, 0.0, 1.0);
        #if LU_WATER_STYLE >= 2
            vec2 waterPosM = waterPos;

            #if LU_WATER_SIZE_MULT != 100
                #define LU_WATER_SIZE_MULT_M LU_WATER_SIZE_MULT * 0.01
                waterPosM *= LU_WATER_SIZE_MULT_M;
            #endif

            #define LU_WATER_BUMPINESS_M LU_WATER_BUMPINESS * 0.8

            #if LU_WATER_STYLE >= 2
                waterPosM *= 2.5; wind *= 2.5;

                #if LU_WATER_MAT_QUALITY >= 2
                    vec2 parallaxMult = -0.01 * viewVector.xy / viewVector.z;
                    for (int i = 0; i < 4; i++) {
                        waterPosM += parallaxMult * texture2D(gaux4, waterPosM - wind).a;
                        waterPosM += parallaxMult * texture2D(gaux4, waterPosM * 0.25 - 0.5 * wind).a;
                    }
                #endif

                vec2 normalMed = texture2D(gaux4, waterPosM + wind).rg - 0.5;
                vec2 normalSmall = texture2D(gaux4, waterPosM * 4.0 - 2.0 * wind).rg - 0.5;
                vec2 normalMicro = texture2D(gaux4, waterPosM * 11.0 + wind * 2.4).rg - 0.5;
                vec2 normalBig = texture2D(gaux4, waterPosM * 0.25 - 0.5 * wind).rg - 0.5;
                     normalBig += texture2D(gaux4, waterPosM * 0.05 - 0.05 * wind).rg - 0.5;

                normalMap.xy = normalMed * (LU_WATER_BUMP_MED * 0.86) + normalSmall * (LU_WATER_BUMP_SMALL * 0.62) + normalBig * (LU_WATER_BUMP_BIG * 0.78);
                normalMap.xy += normalMicro * (0.16 + 0.42 * weatherWave);
                normalMap.xy *= 5.0 * (1.0 - 0.58 * fresnel) * LU_WATER_BUMPINESS_M * (1.0 + 0.28 * weatherWave);
            #endif

            normalMap.xy *= 0.038 * lmCoordM.y + 0.016 + 0.006 * weatherWave;
        #else
            float pNormalMult = 0.02 * rainFactor * inRainy * lu_pow2(lmCoordM.y);

            if (pNormalMult > 0.0005) {
                vec2 puddlePos = floor((playerPos.xz + cameraPosition.xz) * 16.0) * 0.00625;

                vec2 puddleWind = vec2(frameTimeCounter) * 0.015;
                vec2 pNormalCoord1 = puddlePos + vec2(puddleWind.x, puddleWind.y);
                vec2 pNormalCoord2 = puddlePos + vec2(puddleWind.x * -1.5, puddleWind.y * -1.0);
                vec3 pNormalNoise1 = texture2D(noisetex, pNormalCoord1).rgb;
                vec3 pNormalNoise2 = texture2D(noisetex, pNormalCoord2).rgb;

                normalMap.xy = (pNormalNoise1.xy + pNormalNoise2.xy - vec2(1.0)) * pNormalMult;
        #endif

            normalMap.z = sqrt(max(1.0 - (lu_pow2(normalMap.x) + lu_pow2(normalMap.y)), 0.0));
            normalM = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));

        #if LU_WATER_STYLE == 1
            }
        #endif

        #if LU_WATER_STYLE >= 2
            vec3 vector = reflect(nViewPos, normalize(normalM));
            float norMix = lu_pow2(lu_pow2(lu_pow2(1.0 - lu_max0(dot(normal, vector))))) * 0.5;
            normalM = mix(normalM, normal, norMix); // Fixes normals pointing inside water
            normalM = normalize(mix(normalM, normal, (0.08 + 0.10 * nightFactor) * (1.0 - 0.45 * weatherWave)));

            float fresnelP = fresnel;
            fresnel = clamp(1.0 + dot(normalM, nViewPos), 0.0, 1.0);
        #endif
    #endif
    // ============================== End of Step 2 ============================== //

    // ============================== Step 3: Water Material Features ============================== //
    #if LU_WATER_MAT_QUALITY >= 2
        if (isEyeInWater != 1) {
            // Noise Coloring //
            float noise = texture2D(noisetex, (waterPos + wind) * 0.25).g;
                  noise = noise - 0.5;
                  noise *= 0.25;
            color.rgb = pow(color.rgb, vec3(1.0 + noise));

            float surfaceRain = lu_clamp01(rainFactor * max(inRainy, 0.35));
            float surfaceSky = lu_clamp01(lmCoordM.y);
            float broadRipple = texture2D(gaux4, waterPos * 0.72 + wind * 0.22).a;
            float midRipple = texture2D(gaux4, waterPos * 3.60 - wind * 0.78).g;
            float fineRipple = texture2D(gaux4, waterPos * 9.50 + wind * 1.85).r;
            float rippleLines = smoothstep(0.54, 0.88, midRipple * 0.52 + fineRipple * 0.48);
            float rippleTroughs = smoothstep(0.28, 0.72, 1.0 - broadRipple);
            float glintMask = smoothstep(0.82, 0.985, fineRipple + midRipple * 0.24);
            float surfaceDetail = (0.035 + 0.050 * sunVisibility + 0.030 * surfaceRain) * surfaceSky;

            color.rgb *= 1.0 - rippleTroughs * (0.035 + 0.040 * surfaceRain);
            color.rgb += vec3(0.045, 0.125, 0.150) * rippleLines * surfaceDetail;
            color.rgb += vec3(0.220, 0.340, 0.390) * glintMask * surfaceDetail * (1.0 - 0.72 * surfaceRain);

            // Water Alpha //
            #ifdef LU_GBUFFERS_WATER
                float depthT = texelFetch(depthtex1, texelCoord, 0).r;
            #elif defined DH_WATER
                float depthT = texelFetch(dhDepthTex1, texelCoord, 0).r;
            #endif
            vec3 screenPosT = vec3(screenPos.xy, depthT);
            #ifdef LU_TAA
                vec3 viewPosT = lu_ScreenToView(vec3(lu_TAAJitter(screenPosT.xy, -0.5), screenPosT.z));
            #else
                vec3 viewPosT = lu_ScreenToView(screenPosT);
            #endif
            float lViewPosT = length(viewPosT);
            float lViewPosDifM = lViewPos - lViewPosT;

            #if LU_WATER_STYLE < 3
                color.a = lu_sqrt1(color.a);
            #else
                color.a = 0.98;
            #endif

            #ifdef DISTANT_HORIZONS
                if (depthT == 1.0) color.a *= smoothstep(far, far * 0.9, lViewPos);
            #endif

            #if LU_WATER_FOG_MULT != 100
                #define LU_WATER_FOG_MULT_M LU_WATER_FOG_MULT * 0.01;
                lViewPosDifM *= LU_WATER_FOG_MULT_M;
            #endif

            float waterFog = lu_max0(1.0 - exp(lViewPosDifM * 0.075));
            color.a *= 0.25 + 0.75 * waterFog;

            float shallowWater = 1.0 - lu_clamp01(waterFog * 1.25);
            float clearWeather = 1.0 - lu_clamp01(rainFactor * max(inRainy, 0.35));
            vec3 shallowScatter = vec3(0.100, 0.470, 0.440) * (0.35 + 0.65 * sunVisibility);
            vec3 deepScatter = vec3(0.018, 0.085, 0.220);
            vec3 rainyScatter = vec3(0.030, 0.075, 0.095);
            vec3 depthScatter = mix(deepScatter, rainyScatter, rainFactor * 0.75);
            color.rgb = mix(color.rgb, color.rgb + shallowScatter, shallowWater * clearWeather * 0.38);
            color.rgb = mix(color.rgb, color.rgb * depthScatter * 4.0, waterFog * 0.32);

            #if defined LU_BRIGHT_CAVE_WATER && LU_WATER_ALPHA_MULT < 200
                // For better water visibility in caves and some extra color pop outdoors
                color.rgb *= 2.5 - lu_sqrt2(waterFog) - 0.5 * lmCoordM.y;
            #endif

            #if LU_WATER_ALPHA_MULT != 100
                #define LU_WATER_ALPHA_MULT_M 100.0 / LU_WATER_ALPHA_MULT
                color.a = pow(color.a, LU_WATER_ALPHA_MULT_M);
            #endif
            ///

            // Water Foam //
            #if LU_WATER_FOAM_I > 0 && defined LU_GBUFFERS_WATER
                if (NdotU > 0.99) {
                    vec3 matrixM = vec3(
                        gbufferModelViewInverse[0].y,
                        gbufferModelViewInverse[1].y,
                        gbufferModelViewInverse[2].y
                    );
                    float playerPosTY = dot(matrixM, viewPosT) + gbufferModelViewInverse[3].y;
                    float yPosDif = playerPosTY - playerPos.y;

                    #if LU_WATER_STYLE < 3 && MC_VERSION >= 11300
                        float dotColorPM = dot(colorPM, colorPM);
                        float foamThreshold = min(lu_pow2(dotColorPM) * 1.6, 1.2);
                    #else
                        float foamThreshold = lu_pow2(texture2D(noisetex, waterPos * 4.0 + wind * 0.5).g) * 1.6;
                    #endif
                    float edgeFoamMask = 1.0 - smoothstep(0.08, 0.42, abs(yPosDif));
                    float foam = lu_pow2(clamp((foamThreshold + yPosDif) / foamThreshold, 0.0, 1.0));
                    #ifndef END
                        foam *= 0.4 + 0.25 * lmCoord.y;
                    #else
                        foam *= 0.6;
                    #endif
                    foam *= clamp((fract(worldPos.y) - 0.7) * 10.0, 0.0, 1.0);
                    foam *= edgeFoamMask * mix(0.45, 1.0, rainFactor);
                    foam = min(foam, 0.28 + 0.22 * rainFactor);

                    // Subtle edge foam only; the reflective surface stays visible.
                    vec3 foamTint = mix(vec3(0.42, 0.62, 0.72), vec3(0.62, 0.74, 0.82), rainFactor);
                    vec4 foamColor = vec4(foamTint, 1.0);

                    #define LU_WATER_FOAM_IM LU_WATER_FOAM_I * 0.01
                    #if LU_WATER_FOAM_I < 100
                        foam *= LU_WATER_FOAM_IM;
                    #elif LU_WATER_FOAM_I > 100
                        foamColor *= LU_WATER_FOAM_IM;
                    #endif

                    color = mix(color, foamColor, foam);
                    reflectMult = max(reflectMult * (1.0 - foam * 0.35), 0.72);
                }
            #endif
            ///
        } else { // Underwater
            noDirectionalShading = true;

            reflectMult = 0.5;

            #if MC_VERSION < 11300 && LU_WATER_STYLE >= 3
                color.a = 0.7;
            #endif

            #ifdef LU_GBUFFERS_WATER
                #if LU_WATER_STYLE == 1
                    translucentMult.rgb *= 1.0 - fresnel4;
                #else
                    translucentMult.rgb *= 1.0 - 0.9 * max(0.5 * sqrt(fresnel4), fresnel4);
                #endif
            #endif
        }
    #else
        shadowMult = vec3(0.0);
    #endif
    // ============================== End of Step 3 ============================== //

    // ============================== Step 4: Final Tweaks ============================== //
    reflectMult *= 0.5 + 0.5 * NdotUmax0;
    reflectMult *= mix(1.46, 1.72, rainFactor * max(inRainy, 0.35));
    reflectMult = min(reflectMult, 1.72);

    color.a = mix(color.a, 1.0, fresnel4);

    #ifdef LU_GBUFFERS_WATER
        #if LU_WATER_STYLE == 3 || LU_WATER_STYLE == 2 && LU_SUN_MOON_STYLE >= 2
            smoothnessG = 1.0;

            const float WATER_BUMPINESS_M2 = min(LU_WATER_BUMP_MED * LU_WATER_BUMP_SMALL * LU_WATER_BUMPINESS * 0.65, 1.0);
            vec2 lightNormalP = WATER_BUMPINESS_M2 * (normalMed + 0.5 * normalSmall);
            vec3 lightNormal = normalize(vec3(lightNormalP, 1.0) * tbnMatrix);
            highlightMult = dot(lightNormal, lightVec);
            highlightMult = lu_max0(highlightMult) / max(dot(normal, lightVec), 0.17);
            highlightMult = mix(lu_pow2(lu_pow2(highlightMult * 1.15)), 1.0, lu_min1(sqrt(miplevel) * 0.45)) * 0.34;
            highlightMult *= mix(1.05 + 0.38 * sunVisibility, 1.32, rainFactor * max(inRainy, 0.35));
        #else
            smoothnessG = 0.5;

            highlightMult = min(lu_pow2(lu_pow2(dot(colorP.rgb, colorP.rgb) * 0.4)), 0.5);
            highlightMult *= (16.0 - 15.0 * fresnel2) * (sunVisibility > 0.5 ? 1.02 : 0.78);
            highlightMult *= mix(1.05, 1.28, rainFactor * max(inRainy, 0.35));
        #endif
    #endif
    // ============================== End of Step 4 ============================== //
#endif
