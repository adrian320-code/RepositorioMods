materialMask = OSIEBCA; // Intense Fresnel

float factor = max(color.g, 0.8);
float factor2 = lu_pow2(factor);
#ifdef LU_GBUFFERS_TERRAIN
    float factor4 = lu_pow2(factor2);
#else
    float factor4 = factor2;
#endif

smoothnessG = factor - lu_pow2(lu_pow2(color.g)) * 0.4;
highlightMult = 3.0 * max(lu_pow2(factor4), 0.2);

smoothnessD = factor4 * 0.75;

#if MC_VERSION < 11300
    highlightMult *= 2.0;
    smoothnessD /= 0.75;
#endif

color.rgb *= 0.7 + 0.4 * lu_GetLuminance(color.rgb);

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
