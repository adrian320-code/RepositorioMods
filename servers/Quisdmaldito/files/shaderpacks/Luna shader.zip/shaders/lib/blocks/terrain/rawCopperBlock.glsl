materialMask = OSIEBCA * 2.0; // Copper Fresnel
smoothnessG = lu_pow2(color.r + color.g * 0.25) * 0.4;
smoothnessG = lu_min1(smoothnessG);
smoothnessD = lu_min1(smoothnessG * smoothnessG * 2.0);
