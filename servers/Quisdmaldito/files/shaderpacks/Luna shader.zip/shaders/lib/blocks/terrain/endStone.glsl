float factor = lu_pow2(lu_pow2(color.r));
smoothnessG = factor * 0.65;
smoothnessD = smoothnessG * 0.6;

// Lunara Shader: End Stone glow REMOVED (was animated pulse).
// End stone is now fully static.

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.66;
#endif
