materialMask = OSIEBCA; // Intense Fresnel

float factor = color.g;
float factor2 = lu_pow2(factor);
float factor4 = lu_pow2(factor2);
float factor8 = lu_pow2(factor4);

smoothnessG = factor - factor8 * 0.5;
highlightMult = 3.5 * factor8;

smoothnessD = factor8;

#ifdef LU_GBUFFERS_TERRAIN
    lu_DoBrightBlockTweaks(color.rgb, 0.5, shadowMult, highlightMult);
#endif

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
