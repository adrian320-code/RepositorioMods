#ifndef IPBR_COMPATIBILITY_MODE
    // Tweak to prevent the animation of lava causing brightness pulsing
    vec3 avgColor = vec3(0.0);
    ivec2 itexCoordC = ivec2(midCoord * atlasSize + 0.0001);
    for (int x = -8; x < 8; x += 2) {
        for (int y = -8; y < 8; y += 2) {
            avgColor += texelFetch(tex, itexCoordC + ivec2(x, y), 0).rgb;
        }
    }
    color.rgb /= max(lu_GetLuminance(avgColor) * 0.0390625, 0.001);
#else
    color.rgb *= 0.86;
#endif

// =====================================================================
// Lunara Shader: Cinematic Lava v3 (aggressive override + per-tile detail)
// =====================================================================
{
    float lum = lu_GetLuminance(color.rgb);

    // Strong palette
    vec3 darkMagma   = vec3(0.55, 0.06, 0.02);   // deep cooled magma
    vec3 richOrange  = vec3(1.85, 0.75, 0.12);   // rich molten body
    vec3 brightGold  = vec3(2.20, 1.65, 0.55);   // brilliant hot core
    vec3 paleHot     = vec3(2.50, 2.10, 1.20);   // near-white hottest spot

    float c = smoothstep(0.05, 0.98, lum);
    vec3 graded = mix(darkMagma, richOrange, c);
    graded = mix(graded, brightGold, smoothstep(0.45, 0.85, lum));
    graded = mix(graded, paleHot,   smoothstep(0.85, 1.00, lum));

    // Per-tile noise variation (uses tile-local coords, never crosses blocks
    // so it cannot produce rings between adjacent blocks).
    vec2 tileUV = texCoord; // local 0..1 per tile
    float n1 = texture2D(noisetex, tileUV * 2.0 + frameTimeCounter * 0.015).r;
    float n2 = texture2D(noisetex, tileUV * 5.0 - frameTimeCounter * 0.025).r;
    float micro = (n1 * 0.6 + n2 * 0.4) - 0.5; // -0.5..+0.5

    // Subtle warm/cool modulation across the surface
    graded *= 1.0 + micro * 0.18;

    // STRONG blend - replace most of the original tint
    color.rgb = mix(color.rgb, graded, 0.85);
}

#ifdef NETHER
    vec3 worldPos2 = playerPos + cameraPosition;
    vec2 lavaPos = (floor(worldPos2.xz * 16.0) + worldPos2.y * 32.0) * 0.000666;
    vec2 wind = vec2(frameTimeCounter * 0.012, 0.0);

    float noiseSample = texture2D(noisetex, lavaPos + wind).g;
    noiseSample = noiseSample - 0.5;
    noiseSample *= 0.1;
    color.rgb = pow(color.rgb, vec3(1.0 + noiseSample));
#endif

noDirectionalShading = true;
lmCoordM = vec2(0.0);
// Slightly stronger emission so the cinematic look glows nicely
emission = lu_GetLuminance(color.rgb) * 7.5;

// Lunara Shader: Reduce lava emission in Nether for less overwhelming glow
#ifdef NETHER
    emission *= 0.30;
#endif

maRecolor = vec3(clamp(lu_pow2(lu_pow2(lu_pow2(lu_smoothstep1(emission * 0.28)))), 0.12, 0.4) * 1.3) * vec3(1.0, vec2(0.7));

#if LU_RAIN_PUDDLES >= 1
    noPuddles = 1.0;
#endif
