smoothnessG = lu_pow2(color.b) * 0.8;
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
