lmCoordM = vec2(0.0);
color = vec4(0.0);

// ============================================================================
// Lunara Shader: PROCEDURAL UNIFIED NETHER PORTAL
// All math in world-space (playerPos) -> pattern is continuous across the
// entire portal regardless of how many blocks make it up. No texture sampling
// is needed for the visual pattern, eliminating per-tile repetition entirely.
// ============================================================================

float lu_pT = frameTimeCounter;

// 1) Build a continuous 2-D coordinate in ABSOLUTE world space so the
//    pattern is anchored to the portal itself and does NOT shift when the
//    camera moves.
vec3 lu_pAbs = playerPos + cameraPosition;
vec2 lu_pUV  = vec2(lu_pAbs.x + lu_pAbs.z, lu_pAbs.y);

// 2) STATIC plasma pattern (no time component -> portal is fully still).
float w1 = sin(lu_pUV.x *  1.2);
float w2 = sin(lu_pUV.y *  1.0);
float w3 = sin((lu_pUV.x + lu_pUV.y) * 0.85);
float w4 = sin((lu_pUV.x - lu_pUV.y) * 1.3);
float plasma = (w1 + w2 + w3 + w4) * 0.25;        // -1..+1
float plasma01 = plasma * 0.5 + 0.5;              //  0..1

// 3) Static swirl pattern.
float swirl = 0.5 + 0.5 * sin(lu_pUV.x * 0.95) * cos(lu_pUV.y * 0.80);

// 4) Combine layers into a single intensity field.
float pattern = mix(plasma01, swirl, 0.45);
pattern = pow(pattern, 1.4);  // higher contrast: deep darks + bright crests

// 5) Magenta/violet two-tone gradient based on intensity (toned down).
vec3 deepViolet = vec3(0.18, 0.03, 0.50);
vec3 hotPink    = vec3(0.85, 0.35, 1.05);
vec3 baseCol    = mix(deepViolet, hotPink, pattern);

// 6) Subtle filaments: thin streaks between dark regions (dimmer).
float filaments = smoothstep(0.82, 0.96, pattern);
baseCol += filaments * vec3(1.0, 0.7, 1.1) * 0.45;

// 7) Static brightness (no breathing pulse so the portal is fully still).
float breathe = 0.92;

color.rgb = baseCol * breathe;
color.a   = 0.55;  // more transparent (was 0.92)
// Lower emission so portal doesn't blow out the scene
emission  = clamp(pattern * pattern * 4.0 + filaments * 2.5, 0.03, 6.0);

#define LU_PORTAL_REDUCE_CLOSEUP
#ifdef LU_PORTAL_REDUCE_CLOSEUP
    color.a *= lu_min1(lViewPos - 0.2);
    if (color.a < 0.101) {
        if (color.a < 0.101 * dither) discard;
        else color.a = 0.101;
    }
#endif

#ifdef LU_PORTAL_EDGE_EFFECT
    vec3 voxelPos = SceneToVoxel(playerPos);

    if (CheckInsideVoxelVolume(voxelPos)) {
        float portalOffset = 0.0625 * dither;
        vec3[6] portalOffsets = vec3[](
            vec3( portalOffset, 0, 0),
            vec3(-portalOffset, 0, 0),
            vec3( 0, portalOffset, 0),
            vec3( 0,-portalOffset, 0),
            vec3( 0, 0, portalOffset),
            vec3( 0, 0,-portalOffset)
        );

        float edge = 0.0;
        for (int i = 0; i < 6; i++) {
            uint voxel = texelFetch(voxel_sampler, ivec3(voxelPos + portalOffsets[i]), 0).r;
            if (voxel != uint(25)) {
                edge = 1.0; break;
            }
        }

        vec4 edgeColor = vec4(normalize(color.rgb), 1.0);
        // Lunara Shader: STATIC magenta plasma edge glow (no time-based pulse)
        vec3 edgeGlow = vec3(1.6, 0.7, 1.8) * 1.05;
        color.rgb += edgeGlow * smoothstep(0.0, 0.3, abs(newPos.x * newPos.y)) * 0.5;
        color = mix(color, edgeColor, edge);
        emission = mix(emission, 6.0, edge);
    }
#endif
