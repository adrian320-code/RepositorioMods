smoothnessG = lu_pow2(lu_pow2(color.g)) * 8.0;
smoothnessG = lu_min1(smoothnessG);
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.66;
#endif
