#ifdef LU_GBUFFERS_TERRAIN
    smoothnessG = lu_pow2(lu_pow2(color.r));
#else
    smoothnessG = lu_pow2(color.r);
#endif
highlightMult = smoothnessG * 3.0;
smoothnessD = smoothnessG;
materialMask = OSIEBCA; // Intense Fresnel

color.rgb *= 0.6 + 0.5 * lu_GetLuminance(color.rgb);

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.33;
#endif
