smoothnessG = color.b;
smoothnessD = color.b;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.66;
#endif
