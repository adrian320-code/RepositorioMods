smoothnessG = lu_pow2(color.r) * 0.7;
smoothnessG = lu_min1(smoothnessG);
smoothnessD = smoothnessG;
