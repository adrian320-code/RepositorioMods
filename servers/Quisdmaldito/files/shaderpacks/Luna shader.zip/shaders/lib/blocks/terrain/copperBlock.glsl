materialMask = OSIEBCA * 2.0; // Copper Fresnel
smoothnessG = lu_pow2(lu_pow2(color.r)) + lu_pow2(lu_max0(color.g - color.r * 0.5)) * 0.3;
smoothnessG = lu_min1(smoothnessG);
smoothnessD = smoothnessG;

color.rgb *= 0.6 + 0.7 * lu_GetLuminance(color.rgb);

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
