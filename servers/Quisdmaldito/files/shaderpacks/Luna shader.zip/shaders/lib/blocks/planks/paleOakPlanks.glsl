smoothnessG = lu_pow2(color.g) * 0.25;
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.66;
#endif
