materialMask = OSIEBCA * 3.0; // Gold Fresnel

#ifdef LU_GBUFFERS_TERRAIN
    float colorG2 = lu_pow2(color.g);
#else
    float colorG2 = color.g;
#endif
float colorG4 = lu_pow2(colorG2);
float factor = max(color.g, 0.8);

smoothnessG = lu_min1(factor - colorG4 * 0.5);
highlightMult = 3.5 * max(colorG4, 0.2);

smoothnessD = colorG4;

color.rgb *= 0.5 + 0.4 * lu_GetLuminance(color.rgb);

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.33;
#endif
