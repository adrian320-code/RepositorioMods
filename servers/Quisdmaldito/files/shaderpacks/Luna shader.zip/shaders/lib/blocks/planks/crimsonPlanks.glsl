smoothnessG = lu_pow2(color.r) * 0.7;
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.77;
#endif
