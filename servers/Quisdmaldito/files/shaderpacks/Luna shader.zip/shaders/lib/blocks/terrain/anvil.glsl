smoothnessG = color.r;
smoothnessD = color.r;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.33;
#endif
