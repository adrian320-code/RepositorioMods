materialMask = OSIEBCA; // Intense Fresnel
smoothnessG = lu_pow2(lu_pow2(color.r)) * 0.7;
smoothnessD = smoothnessG * 0.6;
