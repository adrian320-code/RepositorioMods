smoothnessG = lu_pow2(lu_pow2(color.r)) * 0.65;
smoothnessD = smoothnessG;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
