materialMask = OSIEBCA; // Intense Fresnel

float factor = lu_pow2(lu_sqrt2(lu_GetLuminance(color.rgb)));
float factor2 = lu_pow2(factor);
float factor4 = lu_pow2(factor2);

smoothnessG = factor - factor4 * 0.4;
highlightMult = 3.0 * factor4;

smoothnessD = factor4 * 0.75;

#ifdef LU_COATED_TEXTURES
    noiseFactor = 0.5;
#endif
