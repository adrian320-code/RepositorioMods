smoothnessG = lu_pow2(lu_pow2(color.g)) * 2.5;
smoothnessG = lu_min1(smoothnessG);
smoothnessD = smoothnessG;
