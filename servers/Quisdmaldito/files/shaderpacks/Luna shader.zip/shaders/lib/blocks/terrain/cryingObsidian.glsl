#include "/lib/blocks/terrain/obsidian.glsl"

highlightMult *= 0.5;

float factor0 = lu_sqrt2(lu_max0(color.b - color.g * 6.0));
float factor1 = lu_pow2(color.b);
emission = 1.35 + lu_pow2(lu_pow2(factor1)) * 7.5;
emission *= factor0;
color.r *= 1.15;

maRecolor = vec3(factor0 * min(lu_max0(factor1 * 0.7 - 0.1) * 1.3, 0.5));
