materialMask = OSIEBCA * 3.0; // Gold Fresnel
smoothnessG = lu_pow2(lu_pow2(color.g));
smoothnessD = 0.5 * (smoothnessG + color.b);
