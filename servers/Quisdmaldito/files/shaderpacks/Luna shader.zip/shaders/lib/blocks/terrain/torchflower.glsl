subsurfaceMode = 1, noSmoothLighting = true, noDirectionalShading = true;

#ifdef LU_GBUFFERS_TERRAIN
    lu_DoFoliageColorTweaks(color.rgb, shadowMult, snowMinNdotU, viewPos, nViewPos, lViewPos, dither);

    #ifdef LU_COATED_TEXTURES
        doTileRandomisation = false;
    #endif
#endif

#if defined LU_GBUFFERS_TERRAIN && !defined IPBR_COMPATIBILITY_MODE
    emission = (1.0 - abs(signMidCoordPos.x)) * lu_max0(0.7 - abs(signMidCoordPos.y + 0.7));
    emission = lu_pow1_5(emission) * 2.5;
#else
    if (color.r + color.g > color.b + 1.1) emission = 0.8;
    else if (color.r > color.g + color.b) emission = 0.2;
#endif
