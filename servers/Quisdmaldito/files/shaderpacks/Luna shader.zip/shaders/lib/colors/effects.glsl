/**
 * =======================================================================================
 * LUNARA SHADER - COLOR EFFECTS SYSTEM
 * Color Modifiers & Environmental Effects
 * =======================================================================================
 *
 * color modification system for dynamic lighting and atmospheric effects.
 * Combines multiple environmental factors to create realistic lighting conditions.
 *
 * Unified System Components:
 * - Time-based color modifiers (dawn, noon, dusk, night)
 * - Dimensional lighting adjustments (Overworld, Nether, End)
 * - Weather-dependent color shifts (rain, storm, clear)
 * - Moon phase influence calculations
 * - Atmospheric color multipliers
 *
 * =======================================================================================
 */

// =======================================================================================
// DYNAMIC LIGHT COLOR MODIFIER SYSTEM
// =======================================================================================

#ifndef LU_INCLUDE_LIGHT_AND_AMBIENT_MULTIPLIERS
    #define LU_INCLUDE_LIGHT_AND_AMBIENT_MULTIPLIERS

    /**
 * Light Color Multiplier Calculator
 *
 * Calculates dynamic light color multipliers based on environmental conditions
 * including time of day, dimension, and weather patterns.
 *
 * @return vec3 - Normalized light color multiplier (0.0-2.0 range typical)
 *
 * Algorithm Flow:
 * 1. Determine current dimension context
 * 2. Calculate time-based color temperature shifts
 * 3. Apply weather-based modifications
 * 4. Blend between environmental states
 */
    vec3 GetLightColorMult() {
        vec3 lightColorMult;

        #ifdef OVERWORLD
            // Time-of-Day Light Temperature System
            vec3 morningLightMult = vec3(LU_LIGHT_MORNING_R, LU_LIGHT_MORNING_G, LU_LIGHT_MORNING_B) * LU_LIGHT_MORNING_I;
            vec3 noonLightMult = vec3(LU_LIGHT_NOON_R, LU_LIGHT_NOON_G, LU_LIGHT_NOON_B) * LU_LIGHT_NOON_I;
            vec3 nightLightMult = vec3(LU_LIGHT_NIGHT_R, LU_LIGHT_NIGHT_G, LU_LIGHT_NIGHT_B) * LU_LIGHT_NIGHT_I;
            vec3 rainLightMult = vec3(LU_LIGHT_RAIN_R, LU_LIGHT_RAIN_G, LU_LIGHT_RAIN_B) * LU_LIGHT_RAIN_I;

            // Smooth transitions between lighting periods
            lightColorMult = mix(noonLightMult, morningLightMult, invNoonFactor2);
            lightColorMult = mix(nightLightMult, lightColorMult, sunVisibility2);

            // Weather influence on light color temperature
            lightColorMult = mix(lightColorMult, dot(lightColorMult, vec3(0.33333)) * rainLightMult, rainFactor);

        #elif defined NETHER
            // Nether Environment: Consistent warm/hellish lighting
            vec3 netherLightMult = vec3(LU_LIGHT_NETHER_R, LU_LIGHT_NETHER_G, LU_LIGHT_NETHER_B) * LU_LIGHT_NETHER_I;
            lightColorMult = netherLightMult;

        #elif defined END
            // End Dimension: Ethereal purple-tinted lighting
            vec3 endLightMult = vec3(LU_LIGHT_END_R, LU_LIGHT_END_G, LU_LIGHT_END_B) * LU_LIGHT_END_I;
            lightColorMult = endLightMult;
        #endif

        return lightColorMult;
    }

    /**
 * Atmospheric Color Multiplier Calculator
 *
 * Calculates atmospheric color influence for ambient lighting and sky colors.
 * Provides seamless transitions between environmental conditions.
 *
 * @return vec3 - Atmospheric color multiplier for ambient calculations
 *
 * Features:
 * - Time-based atmospheric color shifts
 * - Weather-dependent atmospheric tinting
 * - Dimensional atmospheric characteristics
 */
    vec3 GetAtmColorMult() {
        vec3 atmColorMult;

        #ifdef OVERWORLD
            // Atmospheric Color Temperature System
            vec3 morningAtmMult = vec3(LU_ATM_MORNING_R, LU_ATM_MORNING_G, LU_ATM_MORNING_B) * LU_ATM_MORNING_I;
            vec3 noonAtmMult = vec3(LU_ATM_NOON_R, LU_ATM_NOON_G, LU_ATM_NOON_B) * LU_ATM_NOON_I;
            vec3 nightAtmMult = vec3(LU_ATM_NIGHT_R, LU_ATM_NIGHT_G, LU_ATM_NIGHT_B) * LU_ATM_NIGHT_I;
            vec3 rainAtmMult = vec3(LU_ATM_RAIN_R, LU_ATM_RAIN_G, LU_ATM_RAIN_B) * LU_ATM_RAIN_I;

            // Smooth atmospheric transitions
            atmColorMult = mix(noonAtmMult, morningAtmMult, invNoonFactor2);
            atmColorMult = mix(nightAtmMult, atmColorMult, sunVisibility2);

            // Weather influence on atmospheric color
            atmColorMult = mix(atmColorMult, dot(atmColorMult, vec3(0.33333)) * rainAtmMult, rainFactor);

        #elif defined NETHER
            // Nether Atmosphere: Dense, hellish ambiance
            vec3 netherAtmMult = vec3(LU_ATM_NETHER_R, LU_ATM_NETHER_G, LU_ATM_NETHER_B) * LU_ATM_NETHER_I;
            atmColorMult = netherAtmMult;

        #elif defined END
            // End Atmosphere: Void-like, mystical ambiance
            vec3 endAtmMult = vec3(LU_ATM_END_R, LU_ATM_END_G, LU_ATM_END_B) * LU_ATM_END_I;
            atmColorMult = endAtmMult;
        #endif

        return atmColorMult;
    }

    // Global Environmental Color Variables
    // Updated dynamically based on current environmental conditions
    vec3 lightColorMult;       // Primary light source color multiplier
    vec3 atmColorMult;         // Atmospheric/ambient color multiplier
    vec3 sqrtAtmColorMult;     // Square root of atmospheric multiplier for special calculations

#endif //LU_INCLUDE_LIGHT_AND_AMBIENT_MULTIPLIERS

// =======================================================================================
// LUNAR INFLUENCE & NIGHT LIGHTING SYSTEM
// =======================================================================================

#ifndef LU_INCLUDE_MOON_PHASE_INF
    #define LU_INCLUDE_MOON_PHASE_INF

    #ifdef OVERWORLD
        /**
 * Moon Phase Lighting Calculator
 *
 * Provides realistic lunar influence on nighttime lighting conditions.
 * Creates dynamic brightness variations based on moon visibility.
 *
 * Moon Phase System:
 * - Phase 0: Full Moon (Maximum brightness - LU_MOON_PHASE_FULL)
 * - Phase 1-3: Waxing phases (Partial brightness - LU_MOON_PHASE_PARTIAL)
 * - Phase 4: New Moon (Minimum brightness - LU_MOON_PHASE_DARK)
 * - Phase 5-7: Waning phases (Partial brightness - LU_MOON_PHASE_PARTIAL)
 *
 * Technical Implementation:
 * - Only affects nighttime lighting (controlled by sunVisibility2)
 * - Smooth transitions prevent jarring brightness changes
 * - Configurable through shader settings for customization
 */
        float moonPhaseInfluence = mix(
            1.0,  // Day time: No moon influence
            moonPhase == 0 ? LU_MOON_PHASE_FULL :        // Full moon: Maximum brightness
            moonPhase != 4 ? LU_MOON_PHASE_PARTIAL :     // Partial phases: Medium brightness
            LU_MOON_PHASE_DARK,                          // New moon: Minimum brightness
            1.0 - sunVisibility2                      // Apply only during night
        );
    #else
        /**
 * Non-Overworld Dimensions: Static lighting
 * Nether and End dimensions maintain consistent lighting without lunar influence
 */
        const float moonPhaseInfluence = 1.0;
    #endif

#endif //LU_INCLUDE_MOON_PHASE_INF

/**
 * =======================================================================================
 * END OF COLOR EFFECTS SYSTEM
 * Lunara Shader Pack Component
 * =======================================================================================
 *
 * This color effects system provides:
 * - Dynamic time-based color temperature adjustments
 * - Dimensional-specific lighting characteristics
 * - Weather-responsive color modifications
 * - Lunar phase influence on nighttime lighting
 * - Smooth environmental transitions
 * - Optimized performance through efficient calculations
 *
 * Key Features:
 * - Realistic lighting progression throughout day/night cycle
 * - Atmospheric color depth and richness
 * - Environmental immersion through dynamic color shifts
 * - Modular design for easy maintenance and expansion
 *
 * Maintained by Lunara - Lunara Shader Development Team
 * =======================================================================================
 */
