// bloom strength control
#define LU_BLOOM_STRENGTH 0.054
// bloom activation system
#define LU_BLOOM
// distance light effects
//#define LU_DISTANT_LIGHT_BOKEH

// Intelligent image sharpening
#define LU_IMAGE_SHARPENING 5
// Motion blur intensity controller
#define LU_MOTION_BLURRING_STRENGTH 1.00
// vignette effect
#define LU_VIGNETTE_R
// Chromatic aberration intensity
#define LU_CHROMA_ABERRATION 0
// Lens flare rendering mode
#define LU_LENSFLARE_MODE 0
// Lens flare intensity control
#define LU_LENSFLARE_I 1.00
// Temporal AA processing mode | AA
#define LU_TAA_MODE 1

// World blur mode selection
#define LU_WORLD_BLUR 0
// Depth of field intensity
#define LU_WB_DOF_I 64.0
// Focus distance controller
#define LU_WB_DOF_FOCUS 0
// Day environment blur
#define LU_WB_DB_DAY_I 64.0
// Night environment enhancement
#define LU_WB_DB_NIGHT_I 64.0
// Rain weather blur system
#define LU_WB_DB_RAIN_I 64.0
// Underwater depth effects
#define LU_WB_DB_WATER_I 64.0
// Nether dimension blur control
#define LU_WB_DB_NETHER_I 64.0
// depth blur for End dimension
#define LU_WB_DB_END_I 128.0

// Exposure control
#define LU_T_EXPOSURE 1.40
// White point curve adjustment
#define LU_TM_WHITE_CURVE 2.0
// Lower tone curve control
#define LU_T_LOWER_CURVE 1.10
// Upper tone curve enhancement
#define LU_T_UPPER_CURVE 1.30
// Saturation curve control
#define LU_T_SATURATION 1.00
// Color vibrance enhancement
#define LU_T_VIBRANCE 1.00

//Color Grading//
    //#define LU_COLORGRADING
    #define LU_GR_RR 100
    #define LU_GR_RG 0
    #define LU_GR_RB 0
    #define LU_GR_RC 1.00
    #define LU_GR_GR 0
    #define LU_GR_GG 100
    #define LU_GR_GB 0
    #define LU_GR_GC 1.00
    #define LU_GR_BR 0
    #define LU_GR_BG 0
    #define LU_GR_BB 100
    #define LU_GR_BC 1.00
