// Volumetric caustic lighting system
#define LU_WATER_CAUSTIC_STYLE_DEFINE 3
// underwater view distortion
#define LU_UNDERWATER_DISTORTION

// Underwater red channel intensity (deep glacial)
#define LU_UNDERWATERCOLOR_R 15
// water color mode selection
#define LU_WATERCOLOR_MODE 3
// Underwater blue channel saturation (deep glacial cyan)
#define LU_UNDERWATERCOLOR_B 110

// Wave velocity multiplier control
#define LU_WATER_SPEED_MULT 1.05
// Large scale wave displacement
#define LU_WATER_BUMP_BIG 1.36

// water surface rendering mode
#define LU_WATER_STYLE_DEFINE 3
// Water foam intensity control
#define LU_WATER_FOAM_I 0

// Rain waving multiplier
#define LU_WAVING_I_RAIN_MULT 165
// Botanical leaf dynamics
#define LU_WAVING_LEAVES
// Aquatic vegetation animation
#define LU_WAVING_LILY_PAD
// lava flow simulation
#define LU_WAVING_LAVA
// Motion intensity controller
#define LU_WAVING_I 1.00

// Surface roughness control
#define LU_WATER_BUMPINESS 1.18
// Water red channel intensity (tropical turquoise)
#define LU_WATERCOLOR_R 55
// Environmental animation speed
#define LU_WAVING_SPEED 1.00

// Water green channel saturation (glacial cyan)
#define LU_WATERCOLOR_G 175
// Underwater green channel intensity (deep glacial)
#define LU_UNDERWATERCOLOR_G 40
// Water blue channel vibrancy (glacial cyan)
#define LU_WATERCOLOR_B 215

// Precipitation response system
#define LU_WAVING_RAIN
// Indoor motion suppression
#define LU_NO_WAVING_INDOORS
// cave water lighting
#define LU_BRIGHT_CAVE_WATER
// Vegetation dynamics system
#define LU_WAVING_FOLIAGE

// Transparency modulation factor
#define LU_WATER_ALPHA_MULT 135
// Medium wave pattern control
#define LU_WATER_BUMP_MED 1.46
// Vertex-level water animation
#define LU_WAVING_WATER_VERTEX
// Refractive index controller
#define LU_WATER_REFRACTION_INTENSITY 2.65

// Atmospheric fog density multiplier
#define LU_WATER_FOG_MULT 165
// Wave scale enhancement factor
#define LU_WATER_SIZE_MULT 100
// Fine detail wave control
#define LU_WATER_BUMP_SMALL 1.34
