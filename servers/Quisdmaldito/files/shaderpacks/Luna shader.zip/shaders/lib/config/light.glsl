// redstone block emission
#define LU_EMISSIVE_REDSTONE_BLOCK
// amethyst glow system
#define LU_GLOWING_AMETHYST 2
// Custom emission intensity control
#define LU_CUSTOM_EMISSION_INTENSITY 40

// LU_POM surface detail depth control | LU_POM
#define LU_POM_DEPTH 0.80
// lighting calculation mode
#define LU_POM_LIGHTING_MODE 2
// Distance-based quality optimization
#define LU_POM_DISTANCE 32

// Underground illumination enhancement
#define LU_CAVE_LIGHTING 100
// Dynamic light flicker simulation
#define LU_BLOCKLIGHT_FLICKERING 0
// Held item illumination mode
#define LU_HELD_LIGHTING_MODE 2

// ore glow controller
#define LU_GLOWING_ORE_MASTER 2
// lichen luminescence
#define LU_GLOWING_LICHEN 2
// Ore glow intensity multiplier
#define LU_GLOWING_ORE_MULT_BASE 0.25
// Dynamic ore glow with flickering effect
#define LU_GLOWING_ORE_MULT (LU_GLOWING_ORE_MULT_BASE * lu_getOreFlickerMultiplier(playerPos + cameraPosition, frameTimeCounter))

#if LU_GLOWING_ORE_MASTER == 2 || LU_SHADER_STYLE == 4 && LU_GLOWING_ORE_MASTER == 1
    // Precious metal ore illumination
    #define LU_GLOWING_ORE_GOLD
    #define LU_GLOWING_ORE_DIAMOND
    #define LU_GLOWING_ORE_EMERALD
    // Base metal ore enhancement
    #define LU_GLOWING_ORE_IRON
    #define LU_GLOWING_ORE_COPPER
    // Functional ore highlighting
    #define LU_GLOWING_ORE_REDSTONE
    #define LU_GLOWING_ORE_LAPIS
    // Nether realm ore control
    #define LU_GLOWING_ORE_GILDEDBLACKSTONE
    // Modded content compatibility
    #define LU_GLOWING_ORE_MODDED
#endif

// Generated normal map intensity
#define LU_GENERATED_NORMAL_MULT 100
// Normal mapping strength control
#define LU_NORMAL_MAP_STRENGTH 100
// Entity normal generation system
#define LU_ENTITY_GN_AND_CT

// portal visual effects
#define LU_SPECIAL_PORTAL_EFFECTS

// Coated texture enhancement multiplier
#define LU_COATED_TEXTURE_MULT 100
// Lapis lazuli block emission
#define LU_EMISSIVE_LAPIS_BLOCK
// Glass transparency control
#define LU_GLASS_OPACITY 0.25

// Shadow frustum fitting algorithm
#define LU_SHADOW_FRUSTUM_FIT
// Entity glow stability fix
#define LU_GLOWING_ENTITY_FIX
// Light flickering correction
#define LU_FLICKERING_FIX

// High-quality shadow filtering
#define LU_SHADOW_FILTERING
// directional shading
#define LU_DIRECTIONAL_SHADING
// Environmental side shadowing
#define LU_SIDE_SHADOWING
// Player shadow casting mode
#define LU_PLAYER_SHADOW 1

// Ambient illumination multiplier
#define LU_AMBIENT_MULT 100
// PBR emission processing mode | PBR
#define LU_IPBR_EMISSIVE_MODE 1
// Directional block light control
#define LU_DIRECTIONAL_BLOCKLIGHT 0

// Nether emission reduction
#ifdef NETHER
    #define LU_NETHER_EMISSION_REDUCTION 0.3
#else
    #define LU_NETHER_EMISSION_REDUCTION 1.0
#endif

// LU_POM rendering quality level | LU_POM
#define LU_POM_QUALITY 128

// Ore flickering animation speed
#define LU_ORE_FLICKER_SPEED 2.5

// Generate flickering multiplier for ore glow
float lu_getOreFlickerMultiplier(vec3 worldPos, float time) {
    // Create unique seed based on world position
    float seed = dot(floor(worldPos * 0.1), vec3(12.9898, 78.233, 45.164));

    // Generate smooth flickering pattern
    float flicker1 = sin(time * LU_ORE_FLICKER_SPEED + seed) * 0.5 + 0.5;
    float flicker2 = sin(time * LU_ORE_FLICKER_SPEED * 1.7 + seed * 1.3) * 0.3 + 0.7;

    // Combine flickering patterns for natural effect
    float combinedFlicker = flicker1 * flicker2;

    // Apply smooth transitions
    return mix(0.3, 1.0, combinedFlicker);
}
