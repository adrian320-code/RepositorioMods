// Celestial body visibility during precipitation
#define LU_SUN_MOON_DURING_RAIN
// Horizon- celestial rendering
#define LU_SUN_MOON_HORIZON
// celestial object style
#define LU_SUN_MOON_STYLE_DEFINE -1

// stellar density control
#define LU_NIGHT_STAR_AMOUNT 3
// Nebula intensity modulator
#define LU_NIGHT_NEBULA_I 120

// Weather texture opacity controller
#define LU_WEATHER_TEX_OPACITY 100
// Precipitation rendering mode
#define LU_RAIN_STYLE 1
// Optical atmospheric effects
#define LU_RAINBOWS 1

// Dynamic cloud shadow casting
//#define LU_CLOUD_SHADOWS
// cloud area detection
//#define LU_CLOUD_CLOSED_AREA_CHECK
// Cloud blue channel vibrancy
#define LU_CLOUD_B 115

// Cloud scale enhancement multiplier
#define LU_CLOUD_UNBOUND_SIZE_MULT 180
// Weather-responsive cloud density
#define LU_CLOUD_UNBOUND_RAIN_ADD 0.75

// Cloud green channel saturation
#define LU_CLOUD_G 110
// Atmospheric movement velocity
#define LU_CLOUD_SPEED_MULT 85
// cloud style selector
#define LU_CLOUD_STYLE_DEFINE 1

// Aurora visibility conditions
#define LU_AURORA_CONDITION 3
// Aurora rendering style control
#define LU_AURORA_STYLE_DEFINE -1

// atmospheric depth fog
#define LU_ATMOSPHERIC_FOG
// Conditional bloom fog system
#define LU_BLOOM_FOG
    // Nether environment optimization
    #ifdef NETHER
        #undef LU_BLOOM_FOG
    #endif

// Volumetric cloud density control
#define LU_CLOUD_UNBOUND_AMOUNT 1.85
// Cloud red channel warmth
#define LU_CLOUD_R 105
