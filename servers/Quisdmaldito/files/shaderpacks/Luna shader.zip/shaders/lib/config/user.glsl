// shadow rendering quality
#define LU_SHADOW_QUALITY 2
// Shadow distance optimization
const float shadowDistance = 160.0;
// cloud rendering quality
#define LU_CLOUD_QUALITY 3
// Block reflection quality control
#define LU_BLOCK_REFLECT_QUALITY 2

// shader style selector
#define LU_SHADER_STYLE 1
// Rendering pipeline mode
#define LU_RP_MODE 1
// Detail quality enhancement
#define LU_DETAIL_QUALITY 2

// Colored lighting system control
#define LU_COLORED_LIGHTING 0
#if defined IRIS_FEATURE_CUSTOM_IMAGES && LU_SHADOW_QUALITY > -1 && !defined MC_OS_MAC && !(defined DH_TERRAIN || defined DH_WATER)
    #define LU_COLORED_LIGHTING_INTERNAL LU_COLORED_LIGHTING
    #if LU_COLORED_LIGHTING_INTERNAL > 0
        // Color saturation enhancement
        #define LU_COLORED_LIGHT_SATURATION 100
        // fog lighting effects
        #define LU_COLORED_LIGHT_FOG
        // Fog lighting intensity
        #define LU_COLORED_LIGHT_FOG_I 0.65
        // Dimensional portal edge effects
        #define LU_PORTAL_EDGE_EFFECT
        #ifndef IRIS_HAS_CONNECTED_TEXTURES
            // Connected glass visual effects
            #define LU_CONNECTED_GLASS_EFFECT
        #endif
    #endif
#else
    #define LU_COLORED_LIGHTING_INTERNAL 0
#endif

// Nether dimension view distance
#define LU_NETHER_VIEW_LIMIT 99999.0
// Nether storm system
#define LU_NETHER_STORM
// Storm altitude control
#define LU_NETHER_STORM_LOWER_ALT 28
// Storm intensity modulator (raised for moodier nether atmosphere)
#define LU_NETHER_STORM_I 0.65

// Lunara Shader: End dimension swirling tornado fog
#define LU_END_STORM
#define LU_END_STORM_I 0.10
#define LU_END_STORM_SPEED 0.55

// Aurora visibility system
#define LU_AURORA_STYLE_DEFINE -1
// Aurora environmental conditions
#define LU_AURORA_CONDITION 3
// stellar density
#define LU_NIGHT_STAR_AMOUNT 3
// Atmospheric rainbow effects
#define LU_RAINBOWS 1

// Fast approximate anti-aliasing
#define LU_FXAA_DEFINE 1
// Shadow smoothing quality
#define LU_SHADOW_SMOOTHING 3
// Entity shadow rendering
#define LU_ENTITY_SHADOWS_DEFINE -1

// Selection outline mode
#define LU_SELECT_OUTLINE 1
// Outline intensity control
#define LU_SELECT_OUTLINE_I 1.00
// RGB color channel control | RGB
#define LU_SELECT_OUTLINE_R 1.35
#define LU_SELECT_OUTLINE_G 0.35
#define LU_SELECT_OUTLINE_B 1.75

// Moon phase reflection influence
#define LU_MOON_PHASE_INF_REFLECTION
// Full moon lighting intensity
#define LU_MOON_PHASE_FULL 1.00
// Partial moon phase intensity
#define LU_MOON_PHASE_PARTIAL 0.85

// Dynamic border fog system
#define LU_BORDER_FOG
    // Nether environment fog optimization
    #ifdef NETHER
        #undef LU_BORDER_FOG
    #endif
// Atmospheric fog multiplier
#define LU_ATM_FOG_MULT 0.65
// Fog distance control
#define LU_ATM_FOG_DISTANCE 130
// Cave atmospheric fog
#define LU_CAVE_FOG

// Particle density reduction
#define LU_REDUCE_CLOSE_PARTICLES
// Lava fog intensity reduction
#define LU_LESS_LAVA_FOG
// Anisotropic filtering quality
#define LU_ANISOTROPIC_FILTER 0

// Hand movement animation
#define LU_HAND_SWAYING 0
// Light level visualization
#define LU_SHOW_LIGHT_LEVEL 0
// Solar positioning control
#define LU_SUN_ANGLE -1

// Water reflection quality
#define LU_WATER_REFLECT_QUALITY 2
// Rain puddle rendering
#define LU_RAIN_PUDDLES 1

// SSAO quality control | SSAO
#define LU_SSAO_QUALI_DEFINE 2
// SSAO intensity | SSAO
#define LU_SSAO_I 0
// Vanilla AO intensity | AO
#define LU_VANILLAAO_I 100

// Light shaft behavior mode
#define LU_LIGHTSHAFT_BEHAVIOUR 1
// Light shaft quality definition (0=off, 1=low, 2=med, 3=high, 4=ultra)
#define LU_LIGHTSHAFT_QUALI_DEFINE 2

// === ADVANCED GOD RAYS SYSTEM ===
// Master toggle for the enhanced god rays (HG phase + dust)
#define LU_GODRAYS_ENHANCED
// Overall intensity multiplier (50-300, 100=default)
#define LU_GODRAYS_INTENSITY 145
// Forward-scattering anisotropy strength (0-99) - sharper rays around sun
#define LU_GODRAYS_ANISOTROPY 68
// Atmospheric dust/smoke density inside rays (0=off, 1=on)
#define LU_GODRAYS_DUST 0

// Procedural volumetric dust inside light shafts (auto-gated by LU_GODRAYS_DUST)
#if LU_GODRAYS_DUST > 0
    #define LIGHTSHAFT_SMOKE
#endif
// Day light shaft intensity
#define LU_LIGHTSHAFT_DAY_I 102
// Night light shaft enhancement
#define LU_LIGHTSHAFT_NIGHT_I 112

// Weather texture opacity
#define LU_WEATHER_TEX_OPACITY 100
// Rain rendering style
#define LU_RAIN_STYLE 1
// Rain light shaft intensity
#define LU_LIGHTSHAFT_RAIN_I 86

// World outline thickness control
#define LU_WORLD_OUTLINE_THICKNESS 1
// World outline intensity
#define LU_WORLD_OUTLINE_I 1.50
// Entity outline rendering
#define LU_WORLD_OUTLINE_ON_ENTITIES
// Dark outline enhancement
#define LU_DARK_OUTLINE_THICKNESS 1

// Celestial object style
#define LU_SUN_MOON_STYLE_DEFINE -1
// Horizon celestial visibility
#define LU_SUN_MOON_HORIZON
// Celestial visibility during rain
#define LU_SUN_MOON_DURING_RAIN

// Nether color mode selection
#define LU_NETHER_COLOR_MODE 3
// Nether storm height control
#define LU_NETHER_STORM_HEIGHT 200
// Atmospheric fog altitude
#define LU_ATM_FOG_ALTITUDE 70

// === ADVANCED NIGHT SKY SYSTEM ===
// Milky Way galaxy band across the night sky
#define LU_GALAXY_BAND
// Galaxy intensity (50-300, default 130)
#define LU_GALAXY_I 140
// Star twinkle / shimmer effect
#define LU_STAR_TWINKLE
// Per-star color variation (blue/white/orange stellar classes)
#define LU_STAR_COLORS
// Random shooting stars (meteors)
#define LU_SHOOTING_STARS
// Shooting star frequency (1=rare, 5=often, 8=meteor shower)
#define LU_SHOOTING_STARS_RATE 4

// Giant planet in the night sky
#define LU_GIANT_PLANET
// Planet apparent size (5-25, default 12)
#define LU_PLANET_SIZE 12
// Planet brightness multiplier (50-300, default 150)
#define LU_PLANET_INTENSITY 150
// Planet style: 1 = banded gas giant (Jupiter-like), 2 = cracked rocky moon, 3 = ringed world (Saturn-like)
#define LU_PLANET_STYLE 3

// Nether-specific light shaft optimization (enhanced cinematic god rays)
#ifdef NETHER
    #undef LU_LIGHTSHAFT_DAY_I
    #undef LU_LIGHTSHAFT_NIGHT_I
    #undef LU_LIGHTSHAFT_RAIN_I
    #define LU_LIGHTSHAFT_DAY_I 110
    #define LU_LIGHTSHAFT_NIGHT_I 110
    #define LU_LIGHTSHAFT_RAIN_I 110
#endif

// Dark moon phase intensity
#define LU_MOON_PHASE_DARK 0.60
// Nebula intensity control
#define LU_NIGHT_NEBULA_I 120

// Pixel scale enhancement
#define LU_PIXEL_SCALE 1

// Biome color grading
#define LU_BIOME_COLOR_GRADING 0 //[0 1]
